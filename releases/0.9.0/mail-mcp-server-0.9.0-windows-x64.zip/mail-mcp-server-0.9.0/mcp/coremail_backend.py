from __future__ import annotations

import base64
import ctypes
import datetime as dt
import hashlib
import hmac
import html
import imaplib
import ipaddress
import json
import math
import mimetypes
import os
import re
import secrets
import socket
import smtplib
import ssl
import tempfile
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from email import policy
from email.header import decode_header
from email.headerregistry import Address
from email.message import EmailMessage, Message
from email.parser import BytesParser
from email.utils import format_datetime, formataddr, getaddresses, make_msgid, parsedate_to_datetime
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterator, Mapping, Sequence

from windows_mapi import (
    INTERFACE_NAME as WINDOWS_MAPI_TRANSPORT,
    MAPI_BCC,
    MAPI_CC,
    MAPI_TO,
    SimpleMapiClient,
    WindowsMapiError,
    detect_coremail_mapi_registration,
)

SERVER_VERSION = "0.9.0"
PACKAGE_NAME = "mail-mcp-server"
DISPLAY_NAME = "邮件助手"
MCP_SERVER_NAME = "mail-mcp"
CONFIG_SCHEMA_VERSION = 1
CONFIG_PROVIDER = "coremail"
AUTH_METHODS = {"password", "plain", "xoauth2", "oauthbearer"}
DEFAULT_TOKEN_TTL_SECONDS = 15 * 60
DEFAULT_MAX_MESSAGE_BYTES = 10 * 1024 * 1024
DEFAULT_MAX_BODY_CHARS = 50_000
DEFAULT_MAX_ATTACHMENT_BYTES = 25 * 1024 * 1024
DEFAULT_MAX_RECIPIENTS = 100
ROOT_CONFIG_FIELDS = {
    "schema_version",
    "provider",
    "transport",
    "username",
    "credential_target",
    "imap",
    "smtp",
    "allowed_from",
    "drafts_folder",
    "sent_folder",
    "sent_copy_mode",
    "ca_file",
    "attachment_roots",
    "max_message_bytes",
    "max_body_chars",
    "max_attachment_bytes",
    "max_recipients",
    "timeout_seconds",
    "auth_method",
    "download_directory",
}
ENDPOINT_CONFIG_FIELDS = {"host", "port", "security"}
_MISSING = object()


class CoremailError(RuntimeError):
    """Base error safe to expose to the MCP caller."""


class ConfigError(CoremailError):
    pass


class CredentialError(CoremailError):
    pass


class MailConnectionError(CoremailError):
    pass


class MailProtocolError(CoremailError):
    pass


class StaleMessageError(CoremailError):
    pass


class PreparedMessageError(CoremailError):
    pass


@dataclass(frozen=True)
class Endpoint:
    host: str
    port: int
    security: str


@dataclass(frozen=True)
class Settings:
    config_path: Path
    transport: str
    username: str
    credential_target: str | None
    imap: Endpoint | None
    smtp: Endpoint | None
    allowed_from: tuple[str, ...]
    drafts_folder: str | None
    sent_folder: str | None
    sent_copy_mode: str
    ca_file: Path | None
    attachment_roots: tuple[Path, ...]
    max_message_bytes: int
    max_body_chars: int
    max_attachment_bytes: int
    max_recipients: int
    timeout_seconds: float
    # Defaults keep the internal dataclass convenient for adapter tests and
    # callers that construct an in-memory settings object. File-backed config
    # parsing still requires these fields explicitly.
    schema_version: int = CONFIG_SCHEMA_VERSION
    provider: str = CONFIG_PROVIDER
    auth_method: str = "password"
    download_directory: Path | None = None

    def public_summary(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "config_path": str(self.config_path),
            "schema_version": self.schema_version,
            "provider": self.provider,
            "transport": self.transport,
            "username": self.username,
            "credential_target": self.credential_target,
            "allowed_from": list(self.allowed_from),
            "drafts_folder": self.drafts_folder,
            "sent_folder": self.sent_folder,
            "sent_copy_mode": self.sent_copy_mode,
            "download_directory": str(self.download_directory) if self.download_directory else None,
            "body_formats": list(self.body_formats),
            "body_capabilities": self.body_capabilities(),
            "ca_file": str(self.ca_file) if self.ca_file else None,
            "attachment_roots": [str(path) for path in self.attachment_roots],
            "limits": {
                "max_message_bytes": self.max_message_bytes,
                "max_body_chars": self.max_body_chars,
                "max_attachment_bytes": self.max_attachment_bytes,
                "max_recipients": self.max_recipients,
                "timeout_seconds": self.timeout_seconds,
            },
        }
        if self.auth_method != "password":
            result["auth_method"] = self.auth_method
        result["imap"] = (
            {"host": self.imap.host, "port": self.imap.port, "security": self.imap.security}
            if self.imap
            else None
        )
        result["smtp"] = (
            {"host": self.smtp.host, "port": self.smtp.port, "security": self.smtp.security}
            if self.smtp
            else None
        )
        return result

    @property
    def body_formats(self) -> tuple[str, ...]:
        """MIME body formats this transport can preserve and submit."""
        if self.transport == WINDOWS_MAPI_TRANSPORT:
            return ("text/plain",)
        return ("text/plain", "text/html")

    def body_capabilities(self) -> dict[str, list[str]]:
        formats = list(self.body_formats)
        if self.transport != WINDOWS_MAPI_TRANSPORT:
            formats.append("text/calendar")
        return {"read_body_formats": formats, "send_body_formats": list(formats)}


def _settings_fingerprint(settings: Settings) -> str:
    """Return a stable, non-secret identity for the active mail settings.

    A prepared message is a user review of both its contents and the transport
    that will submit it.  Keep the fingerprint limited to parsed, non-secret
    settings; the password itself lives outside this process in Credential
    Manager and is deliberately never represented here.
    """

    def endpoint_value(endpoint: Endpoint | None) -> dict[str, Any] | None:
        if endpoint is None:
            return None
        return {"host": endpoint.host, "port": endpoint.port, "security": endpoint.security}

    payload = {
        "config_path": str(settings.config_path),
        "schema_version": settings.schema_version,
        "provider": settings.provider,
        "transport": settings.transport,
        "username": settings.username,
        "credential_target": settings.credential_target,
        "imap": endpoint_value(settings.imap),
        "smtp": endpoint_value(settings.smtp),
        "allowed_from": list(settings.allowed_from),
        "drafts_folder": settings.drafts_folder,
        "sent_folder": settings.sent_folder,
        "sent_copy_mode": settings.sent_copy_mode,
        "ca_file": str(settings.ca_file) if settings.ca_file else None,
        "attachment_roots": [str(path) for path in settings.attachment_roots],
        "max_message_bytes": settings.max_message_bytes,
        "max_body_chars": settings.max_body_chars,
        "max_attachment_bytes": settings.max_attachment_bytes,
        "max_recipients": settings.max_recipients,
        "timeout_seconds": settings.timeout_seconds,
        "auth_method": settings.auth_method,
        "download_directory": str(settings.download_directory) if settings.download_directory else None,
    }
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("ascii")).hexdigest()


def default_config_path(environ: Mapping[str, str] | None = None) -> Path:
    env = os.environ if environ is None else environ
    user_profile = env.get("USERPROFILE", "").strip()
    base = Path(user_profile) if user_profile else Path.home()
    # Preserve the final path lexically on Windows so a reparse point cannot be
    # silently resolved to an external file before the ownership check runs.
    # POSIX development hosts retain their normal canonical path behavior (for
    # example, macOS's /var compatibility link).
    candidate = Path(os.path.abspath(str(base / "mail-mcp-server" / "config" / "settings.json")))
    return candidate if os.name == "nt" else candidate.resolve()


def _assert_default_config_path_safe(path: Path, environ: Mapping[str, str]) -> None:
    """Reject Windows links/junctions in the user-owned settings path."""
    if os.name != "nt":
        return
    profile = environ.get("USERPROFILE", "").strip() or str(Path.home())
    profile_path = Path(os.path.abspath(profile))
    expected = profile_path / "mail-mcp-server" / "config" / "settings.json"
    lexical = Path(os.path.abspath(str(path)))
    # Windows paths are case-insensitive.  ``os.path.normcase`` follows the
    # host Python's path flavour, which is easy to monkey-patch incorrectly in
    # cross-platform tests, so normalize separators and case explicitly here.
    def windows_key(value: Path) -> str:
        return str(value).replace("/", "\\").rstrip("\\").casefold()

    if windows_key(lexical) != windows_key(expected):
        raise ConfigError("mail configuration path is outside the managed user directory")
    cursor = lexical
    while True:
        try:
            metadata = cursor.lstat()
        except FileNotFoundError:
            metadata = None
        except OSError as exc:
            raise ConfigError(f"cannot inspect mail configuration path: {cursor}") from exc
        if metadata is not None and (
            cursor.is_symlink() or bool(getattr(metadata, "st_file_attributes", 0) & 0x400)
        ):
            raise ConfigError(f"mail configuration path traverses an unsupported link or junction: {cursor}")
        if windows_key(cursor) == windows_key(profile_path):
            break
        parent = cursor.parent
        if parent == cursor:
            raise ConfigError("mail configuration path escaped the user profile")
        cursor = parent


def _required_text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"Missing or empty configuration field: {field}")
    text = value.strip()
    if any(ord(character) < 32 or ord(character) == 127 for character in text):
        raise ConfigError(f"Configuration field contains a control character: {field}")
    return text


def _reject_unknown_fields(value: Mapping[str, Any], field: str, allowed: set[str]) -> None:
    unknown = sorted(str(key) for key in value if key not in allowed)
    if unknown:
        raise ConfigError(f"Unknown configuration field(s) in {field}: {', '.join(unknown)}")


def _hostname(value: Any, field: str) -> str:
    host = _required_text(value, field)
    if len(host) > 253 or any(character.isspace() for character in host):
        raise ConfigError(f"Invalid server hostname in {field}")
    if any(character in host for character in ("/", "\\", "@", "?", "#")) or "://" in host:
        raise ConfigError(f"{field} must be a hostname or IP address, not a URL")
    ip_candidate = host[1:-1] if host.startswith("[") and host.endswith("]") else host
    try:
        return str(ipaddress.ip_address(ip_candidate))
    except ValueError:
        if ":" in host or "[" in host or "]" in host:
            raise ConfigError(f"Invalid server hostname in {field}")
    try:
        ascii_host = host.rstrip(".").encode("idna").decode("ascii")
    except UnicodeError as exc:
        raise ConfigError(f"Invalid server hostname in {field}") from exc
    labels = ascii_host.split(".")
    if not ascii_host or any(
        not label
        or len(label) > 63
        or label.startswith("-")
        or label.endswith("-")
        or re.fullmatch(r"[A-Za-z0-9-]+", label) is None
        for label in labels
    ):
        raise ConfigError(f"Invalid server hostname in {field}")
    return ascii_host


def _positive_int(
    value: Any,
    field: str,
    default: int,
    maximum: int,
    minimum: int = 1,
) -> int:
    if value is _MISSING:
        return default
    # JSON schema integer values must remain integers.  ``int("993")`` and
    # ``int(993.8)`` would silently change a caller's configuration and make
    # the parser disagree with the MCP contract.
    if type(value) is not int:
        raise ConfigError(f"Configuration field must be an integer: {field}")
    number = value
    if number < minimum or number > maximum:
        raise ConfigError(f"Configuration field is outside the supported range: {field}")
    return number


def _bounded_tool_int(value: Any, field: str, default: int, minimum: int, maximum: int) -> int:
    if value is _MISSING:
        return default
    if type(value) is not int:
        raise CoremailError(f"{field} must be an integer")
    number = value
    if number < minimum or number > maximum:
        raise CoremailError(f"{field} must be between {minimum} and {maximum}")
    return number


def _security(value: Any, field: str, default: str) -> str:
    mode = default if value is None else str(value).strip().lower()
    if mode not in {"ssl", "starttls"}:
        raise ConfigError(f"{field} must be 'ssl' or 'starttls'; plaintext is not supported")
    return mode


def _expand_path(value: str, base: Path) -> Path:
    expanded = Path(os.path.expandvars(os.path.expanduser(value)))
    if not expanded.is_absolute():
        expanded = base / expanded
    return expanded.resolve()


def load_settings(
    path: Path | str | None = None,
    environ: Mapping[str, str] | None = None,
) -> Settings:
    env = os.environ if environ is None else environ
    if path is None:
        config_path = default_config_path(env)
        _assert_default_config_path_safe(config_path, env)
    else:
        config_path = Path(path).expanduser().resolve()
    if not config_path.is_file():
        raise ConfigError(
            f"Mail account is not configured. Run scripts/setup-account.ps1 or CONFIGURE.cmd. "
            f"Expected non-secret settings at: {config_path}"
        )
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ConfigError(f"Cannot read mail configuration: {config_path}: {exc}") from exc
    if not isinstance(raw, dict):
        raise ConfigError("Mail configuration root must be a JSON object")
    _reject_unknown_fields(raw, "root", ROOT_CONFIG_FIELDS)

    if "schema_version" not in raw:
        raise ConfigError("Missing or empty configuration field: schema_version")
    schema_version = _positive_int(raw.get("schema_version", _MISSING), "schema_version", CONFIG_SCHEMA_VERSION, 10)
    if schema_version != CONFIG_SCHEMA_VERSION:
        raise ConfigError(f"schema_version must be {CONFIG_SCHEMA_VERSION}")
    if "provider" not in raw:
        raise ConfigError("Missing or empty configuration field: provider")
    provider = _required_text(raw.get("provider"), "provider").lower()
    if provider != CONFIG_PROVIDER:
        raise ConfigError(f"provider must be '{CONFIG_PROVIDER}'")
    transport_raw = raw.get("transport", "imap_smtp")
    transport = (
        _required_text(transport_raw, "transport").lower()
        if "transport" in raw
        else "imap_smtp"
    )
    if transport not in {"imap_smtp", WINDOWS_MAPI_TRANSPORT}:
        raise ConfigError(
            f"transport must be 'imap_smtp' or '{WINDOWS_MAPI_TRANSPORT}'"
        )
    username = _required_text(raw.get("username"), "username")
    imap_raw = raw.get("imap")
    smtp_raw = raw.get("smtp")
    imap: Endpoint | None = None
    smtp: Endpoint | None = None
    if transport == "imap_smtp":
        if not isinstance(imap_raw, dict) or not isinstance(smtp_raw, dict):
            raise ConfigError("Both imap and smtp configuration objects are required for imap_smtp")
        _reject_unknown_fields(imap_raw, "imap", ENDPOINT_CONFIG_FIELDS)
        _reject_unknown_fields(smtp_raw, "smtp", ENDPOINT_CONFIG_FIELDS)

        imap = Endpoint(
            host=_hostname(imap_raw.get("host"), "imap.host"),
            port=_positive_int(imap_raw.get("port", _MISSING), "imap.port", 993, 65535),
            security=_security(imap_raw.get("security"), "imap.security", "ssl"),
        )
        smtp = Endpoint(
            host=_hostname(smtp_raw.get("host"), "smtp.host"),
            port=_positive_int(smtp_raw.get("port", _MISSING), "smtp.port", 465, 65535),
            security=_security(smtp_raw.get("security"), "smtp.security", "ssl"),
        )
    elif imap_raw is not None or smtp_raw is not None:
        raise ConfigError(f"imap and smtp settings are not permitted for {WINDOWS_MAPI_TRANSPORT}")

    allowed_from_raw = raw.get("allowed_from", [username])
    if not isinstance(allowed_from_raw, list) or not allowed_from_raw:
        raise ConfigError("allowed_from must be a non-empty JSON array")
    if len(allowed_from_raw) > 20:
        raise ConfigError("allowed_from must contain at most 20 entries")
    allowed_from = tuple(_required_text(item, "allowed_from[]").lower() for item in allowed_from_raw)
    if transport == WINDOWS_MAPI_TRANSPORT and allowed_from != (username.lower(),):
        raise ConfigError(
            f"allowed_from must contain only username for {WINDOWS_MAPI_TRANSPORT}"
        )

    sent_copy_mode_raw = raw.get("sent_copy_mode", "none")
    sent_copy_mode = (
        _required_text(sent_copy_mode_raw, "sent_copy_mode").lower()
        if "sent_copy_mode" in raw
        else "none"
    )
    if sent_copy_mode not in {"none", "append"}:
        raise ConfigError("sent_copy_mode must be 'none' or 'append'")
    if transport == WINDOWS_MAPI_TRANSPORT and sent_copy_mode != "none":
        raise ConfigError(f"sent_copy_mode must be 'none' for {WINDOWS_MAPI_TRANSPORT}")

    ca_file_raw = raw.get("ca_file")
    if ca_file_raw is not None and not isinstance(ca_file_raw, str):
        raise ConfigError("ca_file must be a string path")
    ca_file = _expand_path(ca_file_raw, config_path.parent) if isinstance(ca_file_raw, str) and ca_file_raw.strip() else None
    if ca_file is not None and not ca_file.is_file():
        raise ConfigError(f"Configured CA file does not exist: {ca_file}")
    if transport == WINDOWS_MAPI_TRANSPORT and ca_file_raw is not None:
        raise ConfigError(f"ca_file is not permitted for {WINDOWS_MAPI_TRANSPORT}")

    roots: list[Path] = []
    configured_roots = raw.get("attachment_roots", [])
    if not isinstance(configured_roots, list):
        raise ConfigError("attachment_roots must be a JSON array")
    if len(configured_roots) > 20:
        raise ConfigError("attachment_roots must contain at most 20 entries")
    for item in configured_roots:
        roots.append(_expand_path(_required_text(item, "attachment_roots[]"), config_path.parent))
    project_dir = env.get("CLAUDE_PROJECT_DIR", "").strip()
    if project_dir:
        roots.append(Path(project_dir).expanduser().resolve())
    unique_roots: list[Path] = []
    seen_roots: set[str] = set()
    for root in roots:
        key = os.path.normcase(str(root))
        if key not in seen_roots:
            seen_roots.add(key)
            unique_roots.append(root)

    credential_target_raw = raw.get("credential_target")
    if transport == "imap_smtp":
        credential_target = (
            _required_text(credential_target_raw, "credential_target")
            if credential_target_raw is not None
            else f"MailMcp.Coremail:{username}"
        )
    else:
        if credential_target_raw is not None:
            raise ConfigError(f"credential_target is not permitted for {WINDOWS_MAPI_TRANSPORT}")
        credential_target = None

    drafts_folder = raw.get("drafts_folder")
    sent_folder = raw.get("sent_folder")
    if drafts_folder is not None:
        drafts_folder = _required_text(drafts_folder, "drafts_folder")
    if sent_folder is not None:
        sent_folder = _required_text(sent_folder, "sent_folder")
    if transport == WINDOWS_MAPI_TRANSPORT and (drafts_folder is not None or sent_folder is not None):
        raise ConfigError(f"drafts_folder and sent_folder are not permitted for {WINDOWS_MAPI_TRANSPORT}")

    auth_method = raw.get("auth_method", "password")
    if not isinstance(auth_method, str) or auth_method.strip().lower() not in AUTH_METHODS:
        raise ConfigError("auth_method must be one of password, plain, xoauth2, oauthbearer")
    auth_method = auth_method.strip().lower()
    if transport == WINDOWS_MAPI_TRANSPORT and auth_method != "password":
        raise ConfigError(f"auth_method is not permitted for {WINDOWS_MAPI_TRANSPORT}")

    download_directory_raw = raw.get("download_directory")
    if download_directory_raw is not None and not isinstance(download_directory_raw, str):
        raise ConfigError("download_directory must be a string path")
    if transport == WINDOWS_MAPI_TRANSPORT and download_directory_raw is not None:
        raise ConfigError(f"download_directory is not permitted for {WINDOWS_MAPI_TRANSPORT}")
    download_directory = (
        _expand_path(download_directory_raw, config_path.parent)
        if isinstance(download_directory_raw, str) and download_directory_raw.strip()
        else None
    )
    if download_directory is not None and download_directory.exists() and not download_directory.is_dir():
        raise ConfigError(f"Configured download directory is not a directory: {download_directory}")

    timeout_raw = raw.get("timeout_seconds", _MISSING)
    if timeout_raw is _MISSING:
        timeout_seconds = 20.0
    elif type(timeout_raw) not in {int, float}:
        raise ConfigError("timeout_seconds must be numeric")
    else:
        timeout_seconds = float(timeout_raw)
    if not math.isfinite(timeout_seconds) or timeout_seconds < 1 or timeout_seconds > 120:
        raise ConfigError("timeout_seconds must be between 1 and 120")

    return Settings(
        config_path=config_path,
        schema_version=schema_version,
        provider=provider,
        transport=transport,
        username=username,
        credential_target=credential_target,
        imap=imap,
        smtp=smtp,
        allowed_from=allowed_from,
        drafts_folder=drafts_folder,
        sent_folder=sent_folder,
        sent_copy_mode=sent_copy_mode,
        ca_file=ca_file,
        attachment_roots=tuple(unique_roots),
        max_message_bytes=_positive_int(
            raw.get("max_message_bytes", _MISSING),
            "max_message_bytes",
            DEFAULT_MAX_MESSAGE_BYTES,
            100 * 1024 * 1024,
            1024,
        ),
        max_body_chars=_positive_int(raw.get("max_body_chars", _MISSING), "max_body_chars", DEFAULT_MAX_BODY_CHARS, 500_000),
        max_attachment_bytes=_positive_int(
            raw.get("max_attachment_bytes", _MISSING),
            "max_attachment_bytes",
            DEFAULT_MAX_ATTACHMENT_BYTES,
            100 * 1024 * 1024,
            1024,
        ),
        max_recipients=_positive_int(raw.get("max_recipients", _MISSING), "max_recipients", DEFAULT_MAX_RECIPIENTS, 500),
        timeout_seconds=timeout_seconds,
        auth_method=auth_method,
        download_directory=download_directory,
    )


class _CREDENTIALW(ctypes.Structure):
    _fields_ = [
        ("Flags", ctypes.c_uint32),
        ("Type", ctypes.c_uint32),
        ("TargetName", ctypes.c_wchar_p),
        ("Comment", ctypes.c_wchar_p),
        ("LastWrittenLow", ctypes.c_uint32),
        ("LastWrittenHigh", ctypes.c_uint32),
        ("CredentialBlobSize", ctypes.c_uint32),
        ("CredentialBlob", ctypes.c_void_p),
        ("Persist", ctypes.c_uint32),
        ("AttributeCount", ctypes.c_uint32),
        ("Attributes", ctypes.c_void_p),
        ("TargetAlias", ctypes.c_wchar_p),
        ("UserName", ctypes.c_wchar_p),
    ]


def read_windows_credential(target: str) -> str:
    if os.name != "nt":
        raise CredentialError("Windows Credential Manager is available only on Windows")
    advapi32 = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    credential_pointer = ctypes.POINTER(_CREDENTIALW)()
    advapi32.CredReadW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p]
    advapi32.CredReadW.restype = ctypes.c_int
    advapi32.CredFree.argtypes = [ctypes.c_void_p]
    advapi32.CredFree.restype = None
    if not advapi32.CredReadW(target, 1, 0, ctypes.byref(credential_pointer)):
        error_code = ctypes.get_last_error()
        raise CredentialError(
            f"Windows credential '{target}' is unavailable (error {error_code}). "
            "Run CONFIGURE.cmd to create or update it, then call mail_config_reload."
        )
    try:
        credential = credential_pointer.contents
        blob = ctypes.string_at(credential.CredentialBlob, credential.CredentialBlobSize)
        if not blob:
            raise CredentialError(
                f"Windows credential '{target}' contains an empty password. "
                "Run CONFIGURE.cmd to enter a new credential, then call mail_config_reload."
            )
        try:
            password = blob.decode("utf-16-le").rstrip("\x00")
        except UnicodeDecodeError:
            password = blob.decode("utf-8")
        if not password:
            raise CredentialError(
                f"Windows credential '{target}' contains an empty password. "
                "Run CONFIGURE.cmd to enter a new credential, then call mail_config_reload."
            )
        return password
    finally:
        advapi32.CredFree(credential_pointer)


def get_password(settings: Settings) -> str:
    if settings.transport != "imap_smtp" or not settings.credential_target:
        raise ConfigError("Windows Credential Manager is used only by the imap_smtp transport")
    return read_windows_credential(settings.credential_target)


def credential_available(settings: Settings) -> bool:
    if settings.transport != "imap_smtp":
        return False
    try:
        password = get_password(settings)
        return bool(password)
    except Exception:
        # This is an offline status probe.  ctypes can surface platform-
        # specific exceptions (including loader and argument errors) that do
        # not share one stable base class across Python/Windows versions.
        return False


def _authentication_guidance(settings: Settings, protocol: str, detail: Any = None) -> str:
    """Return a secret-free recovery instruction for authentication failures."""
    credential_kind = "mailbox password" if settings.auth_method == "password" else "OAuth access token"
    suffix = f" Server response: {_safe_protocol_text(detail)}." if detail is not None else ""
    return (
        f"{protocol} authentication failed; the configured {credential_kind} may be expired or invalid."
        f"{suffix} {_credential_update_instruction(settings)}"
        " Never send the password or token to an MCP tool."
    )


def _credential_update_instruction(settings: Settings) -> str:
    credential_kind = "password" if settings.auth_method == "password" else "OAuth access token"
    return f"Run CONFIGURE.cmd to enter a new {credential_kind}, then call mail_config_reload before retrying."


def _imap_authenticate(client: imaplib.IMAP4, settings: Settings, secret: str) -> None:
    """Authenticate without ever replaying a secret after a failed challenge."""
    if settings.auth_method == "password":
        status, _ = client.login(settings.username, secret)
    elif settings.auth_method == "plain":
        sent = False
        def plain(_: bytes | None = None) -> bytes:
            nonlocal sent
            if sent:
                return b""
            sent = True
            return f"\x00{settings.username}\x00{secret}".encode("utf-8")
        status, _ = client.authenticate("PLAIN", plain)
    elif settings.auth_method == "xoauth2":
        sent = False
        def xoauth(_: bytes | None = None) -> bytes:
            nonlocal sent
            if sent:
                return b""
            sent = True
            return f"user={settings.username}\x01auth=Bearer {secret}\x01\x01".encode("utf-8")
        status, _ = client.authenticate("XOAUTH2", xoauth)
    elif settings.auth_method == "oauthbearer":
        sent = False
        def bearer(_: bytes | None = None) -> bytes:
            nonlocal sent
            if sent:
                return b""
            sent = True
            return f"n,a={settings.username},\x01auth=Bearer {secret}\x01\x01".encode("utf-8")
        status, _ = client.authenticate("OAUTHBEARER", bearer)
    else:  # parser prevents this; keep the boundary defensive for in-memory Settings.
        raise ConfigError(f"Unsupported auth_method: {settings.auth_method}")
    if status != "OK":
        raise MailProtocolError("IMAP authentication was not accepted")


def _smtp_authenticate(client: smtplib.SMTP, settings: Settings, secret: str) -> None:
    if settings.auth_method == "password":
        client.login(settings.username, secret)
        return
    if settings.auth_method == "plain":
        sent = False
        def plain(_: bytes | None = None) -> str:
            nonlocal sent
            if sent:
                return ""
            sent = True
            return f"\x00{settings.username}\x00{secret}"
        client.auth("PLAIN", plain)
        return
    if settings.auth_method == "xoauth2":
        sent = False
        def xoauth(_: bytes | None = None) -> str:
            nonlocal sent
            if sent:
                return ""
            sent = True
            return f"user={settings.username}\x01auth=Bearer {secret}\x01\x01"
        client.auth("XOAUTH2", xoauth)
        return
    if settings.auth_method == "oauthbearer":
        sent = False
        def bearer(_: bytes | None = None) -> str:
            nonlocal sent
            if sent:
                return ""
            sent = True
            return f"n,a={settings.username},\x01auth=Bearer {secret}\x01\x01"
        client.auth("OAUTHBEARER", bearer)
        return
    raise ConfigError(f"Unsupported auth_method: {settings.auth_method}")


def tls_context(settings: Settings) -> ssl.SSLContext:
    context = ssl.create_default_context()
    if settings.ca_file:
        context.load_verify_locations(cafile=str(settings.ca_file))
    if hasattr(ssl, "TLSVersion"):
        context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.check_hostname = True
    context.verify_mode = ssl.CERT_REQUIRED
    return context


@contextmanager
def imap_session(settings: Settings) -> Iterator[imaplib.IMAP4]:
    if settings.transport != "imap_smtp" or settings.imap is None:
        raise ConfigError("IMAP is unavailable for the selected transport")
    try:
        password = get_password(settings)
    except CredentialError as exc:
        raise CredentialError(_authentication_guidance(settings, "IMAP", exc)) from exc
    client: imaplib.IMAP4 | None = None
    try:
        context = tls_context(settings)
        if settings.imap.security == "ssl":
            client = imaplib.IMAP4_SSL(
                settings.imap.host,
                settings.imap.port,
                ssl_context=context,
                timeout=settings.timeout_seconds,
            )
        else:
            client = imaplib.IMAP4(settings.imap.host, settings.imap.port, timeout=settings.timeout_seconds)
            client.starttls(ssl_context=context)
        try:
            _imap_authenticate(client, settings, password)
        except (imaplib.IMAP4.error, MailProtocolError) as exc:
            raise MailProtocolError(_authentication_guidance(settings, "IMAP", exc)) from exc
        yield client
    except (CredentialError, ConfigError, MailProtocolError):
        raise
    except imaplib.IMAP4.error as exc:
        raise MailProtocolError(f"IMAP server rejected the operation: {_safe_protocol_text(exc)}") from exc
    except (OSError, ssl.SSLError) as exc:
        raise MailConnectionError(f"IMAP connection failed: {_safe_protocol_text(exc)}") from exc
    finally:
        if client is not None:
            try:
                client.logout()
            except Exception:
                pass


@contextmanager
def smtp_session(settings: Settings) -> Iterator[smtplib.SMTP]:
    if settings.transport != "imap_smtp" or settings.smtp is None:
        raise ConfigError("SMTP is unavailable for the selected transport")
    try:
        password = get_password(settings)
    except CredentialError as exc:
        raise CredentialError(_authentication_guidance(settings, "SMTP", exc)) from exc
    client: smtplib.SMTP | None = None
    try:
        context = tls_context(settings)
        if settings.smtp.security == "ssl":
            client = smtplib.SMTP_SSL(
                settings.smtp.host,
                settings.smtp.port,
                timeout=settings.timeout_seconds,
                context=context,
            )
        else:
            client = smtplib.SMTP(settings.smtp.host, settings.smtp.port, timeout=settings.timeout_seconds)
            client.ehlo()
            client.starttls(context=context)
            client.ehlo()
        try:
            _smtp_authenticate(client, settings, password)
        except smtplib.SMTPException as exc:
            raise MailProtocolError(_authentication_guidance(settings, "SMTP", exc)) from exc
    except (CredentialError, ConfigError):
        raise
    except smtplib.SMTPAuthenticationError as exc:
        raise MailProtocolError(f"SMTP authentication failed (code {exc.smtp_code})") from exc
    except smtplib.SMTPException as exc:
        raise MailProtocolError(f"SMTP server rejected the operation: {_safe_protocol_text(exc)}") from exc
    except (OSError, ssl.SSLError) as exc:
        raise MailConnectionError(f"SMTP connection failed: {_safe_protocol_text(exc)}") from exc

    try:
        if client is None:
            raise MailConnectionError("SMTP connection was not initialized")
        yield client
    finally:
        if client is not None:
            try:
                client.quit()
            except Exception:
                try:
                    client.close()
                except Exception:
                    pass


def _safe_protocol_text(value: Any, limit: int = 300) -> str:
    text = str(value).replace("\r", " ").replace("\n", " ")
    text = re.sub(r"(?i)(password|passwd|pwd|authorization|token|bearer)\s*[:=]\s*\S+", r"\1=<redacted>", text)
    text = re.sub(r"(?i)\bBearer\s+\S+", "Bearer=<redacted>", text)
    return text[:limit]


def imap_utf7_encode(value: str) -> str:
    output: list[str] = []
    buffer: list[str] = []

    def flush() -> None:
        if not buffer:
            return
        raw = "".join(buffer).encode("utf-16-be")
        encoded = base64.b64encode(raw).decode("ascii").rstrip("=").replace("/", ",")
        output.append("&" + encoded + "-")
        buffer.clear()

    for character in value:
        code = ord(character)
        if 0x20 <= code <= 0x7E and character != "&":
            flush()
            output.append(character)
        elif character == "&":
            flush()
            output.append("&-")
        else:
            buffer.append(character)
    flush()
    return "".join(output)


def imap_utf7_decode(value: str) -> str:
    output: list[str] = []
    index = 0
    while index < len(value):
        if value[index] != "&":
            output.append(value[index])
            index += 1
            continue
        end = value.find("-", index)
        if end < 0:
            raise MailProtocolError("Malformed modified UTF-7 mailbox name")
        payload = value[index + 1 : end]
        if not payload:
            output.append("&")
        else:
            standard = payload.replace(",", "/")
            standard += "=" * ((4 - len(standard) % 4) % 4)
            try:
                output.append(base64.b64decode(standard).decode("utf-16-be"))
            except (ValueError, UnicodeDecodeError) as exc:
                raise MailProtocolError("Malformed modified UTF-7 mailbox name") from exc
        index = end + 1
    return "".join(output)


def _imap_quoted(value: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 1000:
        raise CoremailError("IMAP folder name must be a non-empty string of at most 1000 characters")
    if any(ord(character) < 0x20 or ord(character) == 0x7F for character in value):
        raise CoremailError("IMAP folder name contains a control character")
    encoded = imap_utf7_encode(value)
    return '"' + encoded.replace("\\", "\\\\").replace('"', '\\"') + '"'


_LIST_RE = re.compile(r'^\((?P<flags>[^)]*)\)\s+(?P<delimiter>NIL|"(?:\\.|[^"])*")\s+(?P<name>.+)$')


def _unquote_imap(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        value = value[1:-1]
        value = re.sub(r"\\(.)", r"\1", value)
    return value


def list_folders_with_client(client: imaplib.IMAP4) -> list[dict[str, Any]]:
    status, rows = client.list()
    if status != "OK" or rows is None:
        raise MailProtocolError("IMAP LIST failed")
    folders: list[dict[str, Any]] = []
    for row in rows:
        if row is None:
            continue
        text = row.decode("utf-8", errors="replace") if isinstance(row, bytes) else str(row)
        match = _LIST_RE.match(text)
        if not match:
            folders.append({"name": text, "raw_name": text, "flags": [], "delimiter": None, "parse_warning": True})
            continue
        raw_name = _unquote_imap(match.group("name"))
        try:
            name = imap_utf7_decode(raw_name)
        except CoremailError:
            name = raw_name
        delimiter_raw = match.group("delimiter")
        delimiter = None if delimiter_raw == "NIL" else _unquote_imap(delimiter_raw)
        flags = [flag for flag in match.group("flags").split() if flag]
        folders.append({"name": name, "raw_name": raw_name, "flags": flags, "delimiter": delimiter})
    return folders


def _uidvalidity(client: imaplib.IMAP4) -> str | None:
    response = client.response("UIDVALIDITY")
    if not response or not response[1]:
        return None
    value = response[1][0]
    if isinstance(value, bytes):
        value = value.decode("ascii", errors="replace")
    return str(value)


def select_folder(
    client: imaplib.IMAP4,
    folder: str,
    readonly: bool,
    expected_uidvalidity: str | None = None,
) -> dict[str, Any]:
    status, data = client.select(_imap_quoted(folder), readonly=readonly)
    if status != "OK":
        raise MailProtocolError(f"Cannot select IMAP folder: {folder}")
    current_uidvalidity = _uidvalidity(client)
    if expected_uidvalidity is not None and str(expected_uidvalidity) != str(current_uidvalidity):
        raise StaleMessageError(
            f"Folder UIDVALIDITY changed for {folder}; search again before acting on a UID"
        )
    count = 0
    if data and data[0] is not None:
        try:
            count = int(data[0])
        except (TypeError, ValueError):
            count = 0
    return {"folder": folder, "uidvalidity": current_uidvalidity, "message_count": count}


def _imap_date(value: str, field: str) -> str:
    try:
        parsed = dt.date.fromisoformat(value)
    except ValueError as exc:
        raise CoremailError(f"{field} must be an ISO date in YYYY-MM-DD form") from exc
    months = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    return f"{parsed.day:02d}-{months[parsed.month - 1]}-{parsed.year:04d}"


def _search_quoted(value: str, field: str) -> str:
    if "\r" in value or "\n" in value:
        raise CoremailError(f"Search field contains a newline: {field}")
    if len(value) > 500:
        raise CoremailError(f"Search field is too long: {field}")
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _enable_utf8_if_possible(client: imaplib.IMAP4) -> bool:
    capabilities = {item.upper() for item in getattr(client, "capabilities", ())}
    if b"UTF8=ACCEPT" not in capabilities and "UTF8=ACCEPT" not in capabilities:
        return False
    try:
        status, _ = client.enable("UTF8=ACCEPT")
        return status == "OK"
    except (imaplib.IMAP4.error, AttributeError):
        return False


def _uid_search(client: imaplib.IMAP4, criteria: Sequence[str]) -> list[str]:
    contains_unicode = any(any(ord(character) > 127 for character in item) for item in criteria)
    if contains_unicode and _enable_utf8_if_possible(client):
        status, data = client.uid("SEARCH", None, *criteria)
    elif contains_unicode:
        encoded = [item.encode("utf-8") for item in criteria]
        status, data = client.uid("SEARCH", "CHARSET", "UTF-8", *encoded)
    else:
        status, data = client.uid("SEARCH", None, *criteria)
    if status != "OK" or not data:
        raise MailProtocolError("IMAP UID SEARCH failed")
    raw = data[0] or b""
    text = raw.decode("ascii", errors="ignore") if isinstance(raw, bytes) else str(raw)
    return [uid for uid in text.split() if uid.isdigit()]


def _decode_header_value(value: str | None) -> str:
    if not value:
        return ""
    fragments: list[str] = []
    for fragment, encoding in decode_header(value):
        if isinstance(fragment, bytes):
            for candidate in (encoding, "utf-8", "gb18030", "latin-1"):
                if not candidate:
                    continue
                try:
                    fragments.append(fragment.decode(candidate, errors="strict"))
                    break
                except (LookupError, UnicodeDecodeError):
                    continue
            else:
                fragments.append(fragment.decode("utf-8", errors="replace"))
        else:
            fragments.append(fragment)
    return "".join(fragments)


def _date_iso(value: str | None) -> str | None:
    if not value:
        return None
    try:
        parsed = parsedate_to_datetime(value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.timezone.utc)
        return parsed.isoformat()
    except (TypeError, ValueError, OverflowError):
        return value


_UID_RE = re.compile(rb"\bUID\s+(\d+)\b")
_SIZE_RE = re.compile(rb"\bRFC822\.SIZE\s+(\d+)\b")
_FLAGS_RE = re.compile(rb"\bFLAGS\s+\(([^)]*)\)")


def _fetch_payload(rows: Sequence[Any]) -> tuple[bytes, bytes]:
    metadata = b""
    payload = b""
    for row in rows:
        if isinstance(row, tuple) and len(row) >= 2:
            if isinstance(row[0], bytes):
                metadata += row[0]
            if isinstance(row[1], bytes):
                payload += row[1]
        elif isinstance(row, bytes):
            metadata += row
    return metadata, payload


def _fetch_header(client: imaplib.IMAP4, uid: str) -> dict[str, Any]:
    status, rows = client.uid(
        "FETCH",
        uid,
        "(BODY.PEEK[HEADER.FIELDS (FROM TO CC SUBJECT DATE MESSAGE-ID IN-REPLY-TO REFERENCES)] FLAGS RFC822.SIZE)",
    )
    if status != "OK" or rows is None:
        raise MailProtocolError(f"IMAP FETCH failed for UID {uid}")
    metadata, payload = _fetch_payload(rows)
    if not payload:
        raise MailProtocolError(f"Message UID {uid} was not found")
    message = BytesParser(policy=policy.default).parsebytes(payload, headersonly=True)
    uid_match = _UID_RE.search(metadata)
    size_match = _SIZE_RE.search(metadata)
    flags_match = _FLAGS_RE.search(metadata)
    flags = []
    if flags_match:
        flags = [item.decode("ascii", errors="replace") for item in flags_match.group(1).split()]
    return {
        "uid": uid_match.group(1).decode("ascii") if uid_match else uid,
        "subject": _decode_header_value(message.get("Subject")),
        "from": _decode_header_value(message.get("From")),
        "to": _decode_header_value(message.get("To")),
        "cc": _decode_header_value(message.get("Cc")),
        "date": _date_iso(message.get("Date")),
        "message_id": message.get("Message-ID"),
        "in_reply_to": message.get("In-Reply-To"),
        "references": message.get("References"),
        "flags": flags,
        "size": int(size_match.group(1)) if size_match else None,
    }


def search_messages_with_client(
    client: imaplib.IMAP4,
    *,
    folder: str,
    query: Mapping[str, Any],
    limit: int,
    uid_after: int | None = None,
    snapshot_uid: int | None = None,
    expected_uidvalidity: str | None = None,
) -> dict[str, Any]:
    if limit < 1 or limit > 100:
        raise CoremailError("limit must be between 1 and 100")
    allowed_query_fields = {"from", "to", "cc", "bcc", "subject", "text", "since", "before", "sent_since", "sent_before",
                            "unseen", "flagged", "answered", "deleted", "draft", "keyword", "header", "larger", "smaller", "uid", "and", "or", "not"}

    def build(node: Mapping[str, Any], depth: int = 0) -> list[str]:
        if depth > 5:
            raise CoremailError("Search expression is nested too deeply")
        unknown = sorted(str(field) for field in node if field not in allowed_query_fields)
        if unknown:
            raise CoremailError(f"Unknown search query field(s): {', '.join(unknown)}")
        result: list[str] = []
        mapping = (("from", "FROM"), ("to", "TO"), ("cc", "CC"), ("bcc", "BCC"), ("subject", "SUBJECT"), ("text", "TEXT"))
        for field, atom in mapping:
            value = node.get(field)
            if value is not None:
                if not isinstance(value, str):
                    raise CoremailError(f"Search field must be a string: {field}")
                if value.strip():
                    result.extend((atom, _search_quoted(value.strip(), field)))
        for field, atom in (("since", "SINCE"), ("before", "BEFORE"), ("sent_since", "SENTSINCE"), ("sent_before", "SENTBEFORE")):
            if node.get(field) is not None:
                if not isinstance(node[field], str):
                    raise CoremailError(f"Search field must be a string: {field}")
                result.extend((atom, _imap_date(node[field], field)))
        for field, atom in (("unseen", ("UNSEEN", "SEEN")), ("flagged", ("FLAGGED", "UNFLAGGED")),
                            ("answered", ("ANSWERED", "UNANSWERED")), ("deleted", ("DELETED", "UNDELETED")),
                            ("draft", ("DRAFT", "UNDRAFT"))):
            if field in node:
                if not isinstance(node[field], bool):
                    raise CoremailError(f"Search field must be true or false: {field}")
                result.append(atom[0] if node[field] else atom[1])
        if node.get("keyword") is not None:
            keyword = node["keyword"]
            if not isinstance(keyword, str) or not _KEYWORD_RE.fullmatch(keyword):
                raise CoremailError("keyword must be a valid IMAP keyword")
            result.extend(("KEYWORD", keyword))
        if node.get("header") is not None:
            header = node["header"]
            if not isinstance(header, dict) or set(header) != {"name", "value"}:
                raise CoremailError("header must contain name and value")
            name, value = header["name"], header["value"]
            if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z0-9-]{1,64}", name) or not isinstance(value, str):
                raise CoremailError("Invalid header search")
            result.extend(("HEADER", name, _search_quoted(value, "header.value")))
        for field, atom in (("larger", "LARGER"), ("smaller", "SMALLER")):
            if field in node:
                value = node[field]
                if type(value) is not int or value < 0 or value > 100 * 1024 * 1024:
                    raise CoremailError(f"{field} must be an integer between 0 and 104857600")
                result.extend((atom, str(value)))
        if node.get("uid") is not None:
            uid = node["uid"]
            if not isinstance(uid, str) or not re.fullmatch(r"[0-9]+(?::[0-9]+)?", uid):
                raise CoremailError("uid search must be a decimal UID or range")
            result.extend(("UID", uid))
        for combinator in ("and", "or"):
            if combinator in node:
                children = node[combinator]
                if not isinstance(children, list) or not children or len(children) > 20 or not all(isinstance(item, dict) for item in children):
                    raise CoremailError(f"{combinator} must be a non-empty array of search objects")
                child_criteria = [build(item, depth + 1) for item in children]
                if any(not child for child in child_criteria):
                    raise CoremailError(f"{combinator} cannot contain an empty search object")
                if combinator == "and":
                    for child in child_criteria:
                        result.extend(child)
                else:
                    # IMAP OR is binary.  Fold all children into a nested
                    # expression so an OR with three or more branches keeps
                    # every branch instead of overwriting the accumulator.
                    expression = "(" + " ".join(child_criteria[0]) + ")"
                    for child in child_criteria[1:]:
                        expression = "OR " + expression + " (" + " ".join(child) + ")"
                    result.append(expression)
        if "not" in node:
            if not isinstance(node["not"], dict):
                raise CoremailError("not must be a search object")
            child = build(node["not"], depth + 1)
            if not child:
                raise CoremailError("not cannot wrap an empty search object")
            result.extend(["NOT", "(" + " ".join(child) + ")"])
        return result

    criteria = build(query)
    selected = select_folder(client, folder, readonly=True, expected_uidvalidity=expected_uidvalidity)
    if not criteria:
        criteria.append("ALL")

    uids = _uid_search(client, criteria)
    if snapshot_uid is None and uids:
        snapshot_uid = max(int(item) for item in uids)
    if snapshot_uid is not None:
        uids = [item for item in uids if int(item) <= snapshot_uid]
    if uid_after is not None:
        uids = [item for item in uids if int(item) < uid_after]
    uids = sorted(uids, key=int, reverse=True)
    selected_uids = uids[:limit]
    messages = [_fetch_header(client, uid) for uid in selected_uids]
    return {
        **selected,
        "criteria": dict(query),
        "matched_count": len(uids),
        "returned_count": len(messages),
        "messages": messages,
        "snapshot_uid": snapshot_uid,
        "last_uid": int(selected_uids[-1]) if selected_uids else None,
        "has_more": len(uids) > len(messages),
    }


class _TextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.ignored_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"script", "style", "noscript"}:
            self.ignored_depth += 1
        elif self.ignored_depth == 0 and tag in {"br", "p", "div", "li", "tr", "h1", "h2", "h3", "h4"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"script", "style", "noscript"} and self.ignored_depth:
            self.ignored_depth -= 1
        elif self.ignored_depth == 0 and tag in {"p", "div", "li", "tr"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self.ignored_depth == 0:
            self.parts.append(data)

    def text(self) -> str:
        value = html.unescape("".join(self.parts)).replace("\r\n", "\n").replace("\r", "\n")
        value = re.sub(r"[ \t]+", " ", value)
        value = re.sub(r"\n{3,}", "\n\n", value)
        return value.strip()


def _html_to_text(value: str) -> str:
    parser = _TextExtractor()
    parser.feed(value)
    parser.close()
    return parser.text()


def _part_text(part: Message) -> str:
    try:
        return part.get_content()
    except (LookupError, UnicodeDecodeError, AttributeError):
        payload = part.get_payload(decode=True) or b""
        charset = part.get_content_charset() or "utf-8"
        for candidate in (charset, "utf-8", "gb18030", "latin-1"):
            try:
                return payload.decode(candidate)
            except (LookupError, UnicodeDecodeError):
                continue
        return payload.decode("utf-8", errors="replace")


def _mime_tree(part: Message, part_id: str = "1", *, limit: int = 1000) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    pending: list[tuple[Message, str]] = [(part, part_id)]
    while pending and len(result) < limit:
        current, current_id = pending.pop(0)
        payload = current.get_payload(decode=True)
        item: dict[str, Any] = {
            "part_id": current_id,
            "content_type": current.get_content_type(),
            "charset": current.get_content_charset(),
            "content_disposition": current.get_content_disposition(),
            "filename": _decode_header_value(current.get_filename()),
            "content_id": current.get("Content-ID"),
            "transfer_encoding": current.get("Content-Transfer-Encoding"),
            "size": len(payload) if payload is not None else None,
        }
        result.append(item)
        if current.is_multipart():
            children = current.get_payload()
            if isinstance(children, list):
                pending.extend((child, f"{current_id}.{index}") for index, child in enumerate(children, 1))
    if pending:
        result.append({"truncated": True, "reason": f"MIME tree exceeded {limit} parts"})
    return result


def parse_message(raw: bytes, max_body_chars: int) -> dict[str, Any]:
    message = BytesParser(policy=policy.default).parsebytes(raw)
    headers: dict[str, list[str]] = {}
    for name, value in list(message.items())[:200]:
        decoded = _decode_header_value(str(value))
        headers.setdefault(name, []).append(decoded[:4096])
    plain_parts: list[str] = []
    html_parts: list[str] = []
    calendar_parts: list[str] = []
    attachments: list[dict[str, Any]] = []

    # Do not treat text nested inside an attached message as this message's
    # body.  The previous flat walk could leak a forwarded .eml's HTML into
    # the parent message.
    pending: list[Message] = [message]
    while pending:
        part = pending.pop()
        disposition = part.get_content_disposition()
        filename = part.get_filename()
        content_type = part.get_content_type()
        if disposition == "attachment" or filename:
            payload = part.get_payload(decode=True)
            attachments.append(
                {
                    "filename": _decode_header_value(filename),
                    "content_type": content_type,
                    "size": len(payload) if payload is not None else None,
                    "content_id": part.get("Content-ID"),
                }
            )
            continue
        if part.is_multipart():
            children = part.get_payload()
            if isinstance(children, list):
                pending.extend(reversed(children))
            continue
        if content_type == "text/plain":
            plain_parts.append(_part_text(part))
        elif content_type == "text/html":
            html_parts.append(_part_text(part))
        elif content_type == "text/calendar":
            calendar_parts.append(_part_text(part))

    body = "\n\n".join(part.strip() for part in plain_parts if part.strip())
    body_source = "text/plain"
    if not body and html_parts:
        body = _html_to_text("\n".join(html_parts))
        body_source = "text/html converted to text"
    truncated = len(body) > max_body_chars
    if truncated:
        body = body[:max_body_chars] + "…"
    body_text = "\n\n".join(plain_parts) if plain_parts else None
    body_html = "\n".join(html_parts) if html_parts else None
    body_text_truncated = body_text is not None and len(body_text) > max_body_chars
    body_html_truncated = body_html is not None and len(body_html) > max_body_chars
    body_calendar = "\n".join(calendar_parts) if calendar_parts else None
    body_calendar_truncated = body_calendar is not None and len(body_calendar) > max_body_chars
    if body_text_truncated:
        body_text = body_text[:max_body_chars]
    if body_html_truncated:
        body_html = body_html[:max_body_chars]
    if body_calendar_truncated:
        body_calendar = body_calendar[:max_body_chars]

    return {
        "subject": _decode_header_value(message.get("Subject")),
        "headers": headers,
        "from": _decode_header_value(message.get("From")),
        "to": _decode_header_value(message.get("To")),
        "cc": _decode_header_value(message.get("Cc")),
        "bcc": _decode_header_value(message.get("Bcc")),
        "reply_to": _decode_header_value(message.get("Reply-To")),
        "date": _date_iso(message.get("Date")),
        "message_id": message.get("Message-ID"),
        "in_reply_to": message.get("In-Reply-To"),
        "references": message.get("References"),
        "body": body,
        "body_source": body_source,
        "body_truncated": truncated,
        "body_text": body_text,
        "body_text_truncated": body_text_truncated,
        "body_html": body_html,
        "body_html_truncated": body_html_truncated,
        "body_calendar": body_calendar,
        "body_calendar_truncated": body_calendar_truncated,
        "attachments": attachments,
        "mime_parts": _mime_tree(message),
        "content_is_untrusted": True,
    }


def _fetch_rfc822_size(client: imaplib.IMAP4, uid: str) -> int | None:
    status, rows = client.uid("FETCH", str(uid), "(RFC822.SIZE)")
    if status != "OK" or not rows:
        raise MailProtocolError(f"Cannot fetch metadata for message UID {uid}")
    metadata, _ = _fetch_payload(rows)
    match = _SIZE_RE.search(metadata)
    return int(match.group(1)) if match else None


def fetch_raw_chunk_with_client(
    client: imaplib.IMAP4,
    *, folder: str, uid: str, expected_uidvalidity: str | None, offset: int, length: int,
    max_chunk_bytes: int = 256 * 1024,
) -> dict[str, Any]:
    if not str(uid).isdigit():
        raise CoremailError("uid must contain decimal digits only")
    if type(offset) is not int or offset < 0:
        raise CoremailError("offset must be a non-negative integer")
    if type(length) is not int or length < 1 or length > max_chunk_bytes:
        raise CoremailError(f"length must be between 1 and {max_chunk_bytes}")
    selected = select_folder(client, folder, readonly=True, expected_uidvalidity=expected_uidvalidity)
    total = _fetch_rfc822_size(client, uid)
    status, rows = client.uid("FETCH", str(uid), f"(BODY.PEEK[]<{offset}.{length}>)")
    if status != "OK" or rows is None:
        raise MailProtocolError(f"Cannot fetch raw message UID {uid}")
    _, raw = _fetch_payload(rows)
    if total is not None:
        raw = raw[:max(0, min(length, total - offset))]
    return {**selected, "uid": str(uid), "offset": offset, "length": len(raw), "total_size": total,
            "eof": total is not None and offset + len(raw) >= total,
            "data_base64": base64.b64encode(raw).decode("ascii"), "content_type": "message/rfc822"}


def _fetch_full_raw_with_client(client: imaplib.IMAP4, *, folder: str, uid: str,
                                expected_uidvalidity: str | None, max_message_bytes: int,
                                readonly: bool = True) -> tuple[dict[str, Any], bytes, list[str]]:
    selected = select_folder(client, folder, readonly=readonly, expected_uidvalidity=expected_uidvalidity)
    size = _fetch_rfc822_size(client, uid)
    if size is not None and size > max_message_bytes:
        raise CoremailError(f"Message size {size} exceeds the configured read limit {max_message_bytes}")
    status, rows = client.uid("FETCH", str(uid), "(BODY.PEEK[] FLAGS)")
    if status != "OK" or rows is None:
        raise MailProtocolError(f"Cannot fetch message UID {uid}")
    metadata, raw = _fetch_payload(rows)
    if not raw:
        raise MailProtocolError(f"Message UID {uid} was not found")
    if len(raw) > max_message_bytes:
        raise CoremailError(f"Fetched message exceeds the configured read limit {max_message_bytes}")
    match = _FLAGS_RE.search(metadata)
    flags = [item.decode("ascii", errors="replace") for item in match.group(1).split()] if match else []
    return selected, raw, flags


def download_attachment_with_client(client: imaplib.IMAP4, *, folder: str, uid: str, part_id: str,
                                    expected_uidvalidity: str | None, max_message_bytes: int) -> dict[str, Any]:
    if not re.fullmatch(r"[0-9]+(?:\.[0-9]+)*", part_id):
        raise CoremailError("part_id must be a MIME part path such as 2 or 1.2")
    selected, raw, _ = _fetch_full_raw_with_client(client, folder=folder, uid=uid,
                                                    expected_uidvalidity=expected_uidvalidity,
                                                    max_message_bytes=max_message_bytes)
    message = BytesParser(policy=policy.default).parsebytes(raw)
    part: Message = message
    segments = part_id.split(".")
    # `_mime_tree` uses the root as part 1 and children as 1.1, 1.2, ... .
    # Accept the common IMAP shorthand 1, 2, ... for top-level children too;
    # a leading root segment is skipped only for dotted canonical paths.
    if len(segments) > 1 and segments[0] == "1":
        segments = segments[1:]
    for segment in segments:
        if not part.is_multipart() or not isinstance(part.get_payload(), list):
            raise CoremailError(f"MIME part {part_id} does not exist")
        index = int(segment) - 1
        children = part.get_payload()
        if index < 0 or index >= len(children):
            raise CoremailError(f"MIME part {part_id} does not exist")
        part = children[index]
    if part.is_multipart():
        raise CoremailError("The requested MIME part is a container, not downloadable content")
    if part.get_content_disposition() not in {"attachment", "inline"} and not part.get_filename() and not part.get("Content-ID"):
        raise CoremailError("The requested MIME part is message body content, not an attachment")
    data = part.get_payload(decode=True)
    if data is None:
        data = _part_text(part).encode("utf-8")
    return {**selected, "uid": str(uid), "part_id": part_id,
            "filename": _decode_header_value(part.get_filename()),
            "content_type": part.get_content_type(), "content_id": part.get("Content-ID"),
            "size": len(data), "data_base64": base64.b64encode(data).decode("ascii")}


def update_draft_with_client(client: imaplib.IMAP4, *, settings: Settings, message: PreparedMessage,
                             folder: str, uid: str, expected_uidvalidity: str | None,
                             expected_sha256: str | None = None) -> dict[str, Any]:
    if not str(uid).isdigit():
        raise CoremailError("uid must contain decimal digits only")
    selected, old_raw, old_flags = _fetch_full_raw_with_client(client, folder=folder, uid=uid,
                                                                expected_uidvalidity=expected_uidvalidity,
                                                                max_message_bytes=settings.max_message_bytes,
                                                                readonly=False)
    if "\\draft" not in {flag.casefold() for flag in old_flags}:
        raise CoremailError("The target message is not marked as a draft")
    if expected_sha256 and hashlib.sha256(old_raw).hexdigest().lower() != expected_sha256.lower():
        raise StaleMessageError("Draft changed since it was read; prepare again before updating")
    raw = build_email(message).as_bytes(policy=policy.SMTP)
    status, data = client.append(_imap_quoted(folder), "\\Draft", None, raw)
    if status != "OK":
        raise MailProtocolError("IMAP APPEND for draft update failed; existing draft was left unchanged")
    status, _ = client.uid("STORE", str(uid), "+FLAGS.SILENT", "(\\Deleted)")
    return {**selected, "old_uid": str(uid), "new_message_id": message.message_id, "replaced": status == "OK",
            "cleanup_required": status != "OK", "appended": True,
            "server_response": _safe_protocol_text(data[0]) if data else None}


def get_message_with_client(
    client: imaplib.IMAP4,
    *,
    folder: str,
    uid: str,
    expected_uidvalidity: str | None,
    max_message_bytes: int,
    max_body_chars: int,
) -> dict[str, Any]:
    if not str(uid).isdigit():
        raise CoremailError("uid must contain decimal digits only")
    selected = select_folder(client, folder, readonly=True, expected_uidvalidity=expected_uidvalidity)
    status, size_rows = client.uid("FETCH", str(uid), "(RFC822.SIZE FLAGS)")
    if status != "OK" or not size_rows:
        raise MailProtocolError(f"Cannot fetch metadata for message UID {uid}")
    size_metadata, _ = _fetch_payload(size_rows)
    size_match = _SIZE_RE.search(size_metadata)
    size = int(size_match.group(1)) if size_match else None
    if size is not None and size > max_message_bytes:
        raise CoremailError(
            f"Message size {size} exceeds the configured read limit {max_message_bytes}; increase it deliberately if needed"
        )
    status, rows = client.uid("FETCH", str(uid), "(BODY.PEEK[] FLAGS RFC822.SIZE)")
    if status != "OK" or rows is None:
        raise MailProtocolError(f"Cannot fetch message UID {uid}")
    metadata, raw = _fetch_payload(rows)
    if not raw:
        raise MailProtocolError(f"Message UID {uid} was not found")
    if len(raw) > max_message_bytes:
        raise CoremailError("Fetched message exceeds the configured read limit")
    flags_match = _FLAGS_RE.search(metadata)
    flags = []
    if flags_match:
        flags = [item.decode("ascii", errors="replace") for item in flags_match.group(1).split()]
    return {
        **selected,
        "uid": str(uid),
        "size": size if size is not None else len(raw),
        "flags": flags,
        **parse_message(raw, max_body_chars),
    }


def set_seen_with_client(
    client: imaplib.IMAP4,
    *,
    folder: str,
    uid: str,
    expected_uidvalidity: str | None,
    seen: bool,
) -> dict[str, Any]:
    if not str(uid).isdigit():
        raise CoremailError("uid must contain decimal digits only")
    selected = select_folder(client, folder, readonly=False, expected_uidvalidity=expected_uidvalidity)
    operation = "+FLAGS.SILENT" if seen else "-FLAGS.SILENT"
    status, _ = client.uid("STORE", str(uid), operation, "(\\Seen)")
    if status != "OK":
        raise MailProtocolError(f"Cannot update seen state for message UID {uid}")
    return {**selected, "uid": str(uid), "seen": seen, "updated": True}


_FLAG_NAMES = {"\\Seen", "\\Answered", "\\Flagged", "\\Deleted", "\\Draft"}
_KEYWORD_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,31}")


def _validate_flags(values: Any, field: str) -> list[str]:
    if values is None:
        return []
    if not isinstance(values, list) or len(values) > 50:
        raise CoremailError(f"{field} must be an array with at most 50 flags")
    result: list[str] = []
    for raw in values:
        if not isinstance(raw, str) or not raw:
            raise CoremailError(f"Invalid IMAP flag in {field}")
        flag = raw if raw.startswith("\\") else raw
        if flag.startswith("\\"):
            if flag not in _FLAG_NAMES:
                raise CoremailError(f"Unsupported system flag: {flag}")
        elif not _KEYWORD_RE.fullmatch(flag):
            raise CoremailError(f"Invalid IMAP keyword: {flag}")
        if flag not in result:
            result.append(flag)
    return result


def set_flags_with_client(client: imaplib.IMAP4, *, folder: str, uid: str, expected_uidvalidity: str | None,
                          add: Any = None, remove: Any = None) -> dict[str, Any]:
    if not str(uid).isdigit():
        raise CoremailError("uid must contain decimal digits only")
    added, removed = _validate_flags(add, "add"), _validate_flags(remove, "remove")
    overlap = set(added) & set(removed)
    if overlap:
        raise CoremailError("The same flag cannot be added and removed in one operation")
    selected = select_folder(client, folder, readonly=False, expected_uidvalidity=expected_uidvalidity)
    results: list[dict[str, Any]] = []
    for operation, flags in (("+FLAGS.SILENT", added), ("-FLAGS.SILENT", removed)):
        if not flags:
            continue
        status, _ = client.uid("STORE", str(uid), operation, "(" + " ".join(flags) + ")")
        if status != "OK":
            raise MailProtocolError(f"Cannot update flags for message UID {uid}")
        results.append({"operation": operation, "flags": flags})
    return {**selected, "uid": str(uid), "added": added, "removed": removed, "updated": True, "operations": results}


def copy_or_move_with_client(client: imaplib.IMAP4, *, folder: str, uid: str, destination: str,
                             expected_uidvalidity: str | None, move: bool) -> dict[str, Any]:
    if not str(uid).isdigit():
        raise CoremailError("uid must contain decimal digits only")
    if not isinstance(destination, str) or not destination.strip():
        raise CoremailError("destination must be a non-empty folder name")
    selected = select_folder(client, folder, readonly=False, expected_uidvalidity=expected_uidvalidity)
    destination = destination.strip()
    if move and "MOVE" in {item.decode(errors="ignore").upper() if isinstance(item, bytes) else str(item).upper() for item in getattr(client, "capabilities", ())}:
        status, data = client.uid("MOVE", str(uid), _imap_quoted(destination))
        if status != "OK":
            raise MailProtocolError(f"Cannot move message UID {uid}")
        return {**selected, "uid": str(uid), "destination": destination, "moved": True,
                "method": "UID MOVE", "server_response": _safe_protocol_text(data[0]) if data else None}
    status, data = client.uid("COPY", str(uid), _imap_quoted(destination))
    if status != "OK":
        raise MailProtocolError(f"Cannot copy message UID {uid} to {destination}")
    if not move:
        return {**selected, "uid": str(uid), "destination": destination, "copied": True, "method": "UID COPY",
                "server_response": _safe_protocol_text(data[0]) if data else None}
    status, _ = client.uid("STORE", str(uid), "+FLAGS.SILENT", "(\\Deleted)")
    if status != "OK":
        return {**selected, "uid": str(uid), "destination": destination, "copied": True, "moved": False,
                "cleanup_required": True, "method": "UID COPY + \\Deleted"}
    return {**selected, "uid": str(uid), "destination": destination, "copied": True, "moved": True,
            "cleanup_required": True, "method": "UID COPY + \\Deleted"}


def delete_with_client(client: imaplib.IMAP4, *, folder: str, uid: str, expected_uidvalidity: str | None,
                       permanent: bool = False) -> dict[str, Any]:
    if not str(uid).isdigit():
        raise CoremailError("uid must contain decimal digits only")
    selected = select_folder(client, folder, readonly=False, expected_uidvalidity=expected_uidvalidity)
    if not permanent:
        status, _ = client.uid("STORE", str(uid), "+FLAGS.SILENT", "(\\Deleted)")
        if status != "OK":
            raise MailProtocolError(f"Cannot mark message UID {uid} deleted")
        return {**selected, "uid": str(uid), "deleted": True, "permanent": False, "method": "\\Deleted"}
    caps = {item.decode(errors="ignore").upper() if isinstance(item, bytes) else str(item).upper() for item in getattr(client, "capabilities", ())}
    if "UIDPLUS" not in caps:
        raise CoremailError("Permanent deletion requires IMAP UIDPLUS support")
    status, _ = client.uid("STORE", str(uid), "+FLAGS.SILENT", "(\\Deleted)")
    if status != "OK":
        raise MailProtocolError(f"Cannot mark message UID {uid} deleted")
    status, _ = client.uid("EXPUNGE", str(uid))
    if status != "OK":
        raise MailProtocolError(f"Message UID {uid} was marked deleted but could not be expunged")
    return {**selected, "uid": str(uid), "deleted": True, "permanent": True, "method": "UID EXPUNGE"}


def manage_folder_with_client(client: imaplib.IMAP4, *, action: str, folder: str, new_name: str | None = None,
                              allow_nonempty: bool = False) -> dict[str, Any]:
    if not isinstance(folder, str) or not folder.strip():
        raise CoremailError("folder must be a non-empty string")
    folder = folder.strip()
    if folder.casefold() == "inbox" and action in {"delete", "rename"}:
        raise CoremailError("The INBOX folder cannot be deleted or renamed")
    if action == "create":
        status, _ = client.create(_imap_quoted(folder))
    elif action == "delete":
        if not allow_nonempty:
            status, data = client.select(_imap_quoted(folder), readonly=True)
            if status != "OK":
                raise MailProtocolError(f"Cannot inspect folder {folder}")
            count = int((data[0] or b"0").decode(errors="ignore") or 0)
            if count:
                raise CoremailError("Folder is not empty; pass allow_nonempty=true to delete it")
        status, _ = client.delete(_imap_quoted(folder))
    elif action == "rename":
        if not new_name or not isinstance(new_name, str):
            raise CoremailError("new_name is required for rename")
        status, _ = client.rename(_imap_quoted(folder), _imap_quoted(new_name.strip()))
    elif action in {"subscribe", "unsubscribe"}:
        status, _ = getattr(client, action)(_imap_quoted(folder))
    else:
        raise CoremailError("action must be create, rename, delete, subscribe, or unsubscribe")
    if status != "OK":
        raise MailProtocolError(f"IMAP folder operation failed: {action}")
    return {"action": action, "folder": folder, "new_name": new_name, "updated": True}


def _imap_idle_wait(client: imaplib.IMAP4, timeout_seconds: int) -> bool | None:
    """Run one bounded RFC 2177 IDLE cycle on Python 3.13's public socket primitives."""
    sock = getattr(client, "sock", None)
    new_tag = getattr(client, "_new_tag", None)
    if (sock is None or not callable(new_tag) or not hasattr(client, "send") or not hasattr(client, "readline")
            or not hasattr(sock, "gettimeout") or not hasattr(sock, "settimeout")):
        return None
    previous_timeout = sock.gettimeout()
    changed = False
    try:
        tag = new_tag()
        client.send(tag + b" IDLE\r\n")
        sock.settimeout(1.0)
        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            try:
                line = client.readline()
            except socket.timeout:
                continue
            if not line:
                raise MailConnectionError("IMAP IDLE connection closed")
            upper = line.upper()
            if b" EXISTS" in upper or b" EXPUNGE" in upper or b" FETCH" in upper:
                changed = True
                break
        client.send(b"DONE\r\n")
        sock.settimeout(max(1.0, min(10.0, float(timeout_seconds))))
        # Consume the tagged completion response. The line itself is not exposed
        # because it may contain server-specific text.
        client.readline()
        return changed
    except (OSError, imaplib.IMAP4.error) as exc:
        raise MailConnectionError("IMAP IDLE failed") from exc
    finally:
        try:
            sock.settimeout(previous_timeout)
        except OSError:
            pass


def _extract_addr_spec(value: str, field: str) -> str:
    parsed = getaddresses([value])
    if len(parsed) != 1 or not parsed[0][1]:
        raise CoremailError(f"Invalid email address in {field}: {value}")
    address = parsed[0][1]
    if "\r" in address or "\n" in address or "@" not in address:
        raise CoremailError(f"Invalid email address in {field}: {value}")
    try:
        Address(addr_spec=address)
    except Exception as exc:
        raise CoremailError(f"Invalid email address in {field}: {value}") from exc
    return address


def _normalize_addresses(values: Any, field: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    if values is None:
        return (), ()
    if not isinstance(values, list):
        raise CoremailError(f"{field} must be an array of email address strings")
    formatted: list[str] = []
    envelope: list[str] = []
    for item in values:
        if not isinstance(item, str) or not item.strip() or "\r" in item or "\n" in item:
            raise CoremailError(f"Invalid value in {field}")
        parsed = getaddresses([item])
        if len(parsed) != 1 or not parsed[0][1]:
            raise CoremailError(f"Invalid email address in {field}: {item}")
        display_name, address = parsed[0]
        _extract_addr_spec(address, field)
        formatted.append(formataddr((display_name, address), charset="utf-8") if display_name else address)
        envelope.append(address)
    return tuple(formatted), tuple(envelope)


def _safe_header(value: Any, field: str, maximum: int = 998) -> str:
    if value is None:
        return ""
    text = str(value)
    if "\r" in text or "\n" in text:
        raise CoremailError(f"{field} must not contain newlines")
    if len(text) > maximum:
        raise CoremailError(f"{field} exceeds the {maximum}-character limit")
    return text


def _path_within(path: Path, roots: Sequence[Path]) -> bool:
    for root in roots:
        try:
            path.relative_to(root.resolve())
            return True
        except ValueError:
            continue
    return False


@dataclass(frozen=True)
class AttachmentSpec:
    path: Path
    filename: str
    size: int
    sha256: str
    content_type: str | None = None
    disposition: str = "attachment"
    content_id: str | None = None

    def summary(self) -> dict[str, Any]:
        return {
            "path": str(self.path), "filename": self.filename, "size": self.size, "sha256": self.sha256,
            "content_type": self.content_type, "disposition": self.disposition, "content_id": self.content_id,
        }


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _prepare_attachments(settings: Settings, values: Any) -> tuple[AttachmentSpec, ...]:
    if values is None:
        return ()
    if not isinstance(values, list):
        raise CoremailError("attachments must be an array of file paths or objects")
    if values and not settings.attachment_roots:
        raise CoremailError(
            "No outgoing attachment roots are authorized. Configure attachment_roots or run Claude Code from a project directory."
        )
    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", "").strip()
    base = Path(project_dir).resolve() if project_dir else settings.config_path.parent
    attachments: list[AttachmentSpec] = []
    total = 0
    for raw_path in values:
        attachment_options: Mapping[str, Any] = {}
        if isinstance(raw_path, dict):
            attachment_options = raw_path
            raw_path = raw_path.get("path")
            unknown = sorted(str(key) for key in attachment_options if key not in {"path", "filename", "content_type", "disposition", "content_id"})
            if unknown:
                raise CoremailError(f"Unknown attachment field(s): {', '.join(unknown)}")
        if not isinstance(raw_path, str) or not raw_path.strip():
            raise CoremailError("Each attachment must be a non-empty file path")
        candidate = Path(os.path.expandvars(os.path.expanduser(raw_path.strip())))
        if not candidate.is_absolute():
            candidate = base / candidate
        try:
            resolved = candidate.resolve(strict=True)
        except OSError as exc:
            raise CoremailError(f"Attachment does not exist or cannot be resolved: {candidate}") from exc
        if not resolved.is_file():
            raise CoremailError(f"Attachment is not a regular file: {resolved}")
        if not _path_within(resolved, settings.attachment_roots):
            raise CoremailError(f"Attachment is outside the authorized roots: {resolved}")
        size = resolved.stat().st_size
        total += size
        if total > settings.max_attachment_bytes:
            raise CoremailError(
                f"Total attachment size exceeds the configured limit {settings.max_attachment_bytes} bytes"
            )
        filename = attachment_options.get("filename", resolved.name)
        if not isinstance(filename, str) or not filename.strip() or Path(filename).name != filename or any(char in filename for char in "/\\") or filename in {".", ".."}:
            raise CoremailError("attachment filename must be a single safe file name")
        disposition = attachment_options.get("disposition", "attachment")
        if disposition not in {"attachment", "inline"}:
            raise CoremailError("attachment disposition must be attachment or inline")
        content_type = attachment_options.get("content_type")
        if content_type is not None:
            if not isinstance(content_type, str) or not re.fullmatch(r"[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+", content_type):
                raise CoremailError("attachment content_type must be a MIME type")
        content_id = attachment_options.get("content_id")
        if content_id is not None:
            if not isinstance(content_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.+-]{0,127}", content_id.strip("<>")):
                raise CoremailError("attachment content_id must be a simple CID")
            content_id = content_id.strip("<>")
        if disposition == "inline" and not content_id:
            content_id = secrets.token_hex(12)
        attachments.append(
            AttachmentSpec(path=resolved, filename=filename.strip(), size=size, sha256=_hash_file(resolved),
                            content_type=content_type, disposition=disposition, content_id=content_id)
        )
    content_ids = [item.content_id.casefold() for item in attachments if item.content_id]
    if len(content_ids) != len(set(content_ids)):
        raise CoremailError("Inline attachment content_id values must be unique")
    return tuple(attachments)


@dataclass(frozen=True)
class PreparedMessage:
    from_header: str
    from_address: str
    to_headers: tuple[str, ...]
    to_addresses: tuple[str, ...]
    cc_headers: tuple[str, ...]
    cc_addresses: tuple[str, ...]
    bcc_headers: tuple[str, ...]
    bcc_addresses: tuple[str, ...]
    subject: str
    body_text: str
    in_reply_to: str
    references: str
    attachments: tuple[AttachmentSpec, ...]
    message_id: str
    date: dt.datetime
    body_html: str | None = None
    reply_to_headers: tuple[str, ...] = ()
    reply_to_addresses: tuple[str, ...] = ()
    body_calendar: str | None = None
    calendar_method: str = "REQUEST"

    @property
    def all_recipients(self) -> tuple[str, ...]:
        return self.to_addresses + self.cc_addresses + self.bcc_addresses

    @property
    def body_formats(self) -> tuple[str, ...]:
        if self.body_html is None:
            formats = ["text/plain"]
        elif self.body_text:
            formats = ["text/plain", "text/html"]
        else:
            formats = ["text/html"]
        if self.body_calendar is not None:
            formats.append("text/calendar")
        return tuple(formats)

    def summary(self, settings: Settings) -> dict[str, Any]:
        return {
            "transport": settings.transport,
            "from": self.from_header,
            "to": list(self.to_headers),
            "cc": list(self.cc_headers),
            "bcc": list(self.bcc_headers),
            "reply_to": list(self.reply_to_headers),
            "subject": self.subject,
            "body_formats": list(self.body_formats),
            "body_text": self.body_text,
            "body_html": self.body_html,
            "body_character_count": len(self.body_text),
            "body_html_character_count": len(self.body_html or ""),
            "in_reply_to": self.in_reply_to or None,
            "references": self.references or None,
            "calendar": {"method": self.calendar_method, "character_count": len(self.body_calendar or "")} if self.body_calendar is not None else None,
            "attachments": [attachment.summary() for attachment in self.attachments],
            "message_id": self.message_id,
            "date": self.date.isoformat(),
            "sent_copy_mode": settings.sent_copy_mode,
            "prepared_only": True,
            "content_is_untrusted": True,
        }


def prepare_message(settings: Settings, arguments: Mapping[str, Any]) -> PreparedMessage:
    from_value = str(arguments.get("from", settings.username)).strip()
    from_address = _extract_addr_spec(from_value, "from")
    if from_address.lower() not in settings.allowed_from:
        raise CoremailError(
            f"From address is not allowlisted: {from_address}. Allowed values: {', '.join(settings.allowed_from)}"
        )
    parsed_from = getaddresses([from_value])[0]
    from_header = formataddr(parsed_from, charset="utf-8") if parsed_from[0] else from_address

    to_headers, to_addresses = _normalize_addresses(arguments.get("to"), "to")
    cc_headers, cc_addresses = _normalize_addresses(arguments.get("cc"), "cc")
    bcc_headers, bcc_addresses = _normalize_addresses(arguments.get("bcc"), "bcc")
    recipient_count = len(to_addresses) + len(cc_addresses) + len(bcc_addresses)
    if recipient_count == 0:
        raise CoremailError("At least one To, Cc, or Bcc recipient is required")
    if recipient_count > settings.max_recipients:
        raise CoremailError(f"Recipient count exceeds the configured limit {settings.max_recipients}")

    subject_limit = 255 if settings.transport == WINDOWS_MAPI_TRANSPORT else 500
    subject = _safe_header(arguments.get("subject", ""), "subject", subject_limit)
    body_text = arguments.get("body_text", "")
    if not isinstance(body_text, str):
        raise CoremailError("body_text must be a string")
    if len(body_text) > 500_000:
        raise CoremailError("body_text exceeds the 500000-character limit")
    body_html = arguments.get("body_html", None)
    if "body_html" in arguments and not isinstance(body_html, str):
        raise CoremailError("body_html must be a string")
    if isinstance(body_html, str) and len(body_html) > 500_000:
        raise CoremailError("body_html exceeds the 500000-character limit")
    if body_html is not None and settings.transport == WINDOWS_MAPI_TRANSPORT:
        raise CoremailError(
            "Windows Simple MAPI supports text/plain only; configure imap_smtp to send HTML"
        )
    in_reply_to = _safe_header(arguments.get("in_reply_to", ""), "in_reply_to")
    references = _safe_header(arguments.get("references", ""), "references", 4000)
    reply_to_headers, reply_to_addresses = _normalize_addresses(arguments.get("reply_to"), "reply_to")
    body_calendar = arguments.get("body_calendar")
    if body_calendar is not None:
        if not isinstance(body_calendar, str) or len(body_calendar) > 500_000:
            raise CoremailError("body_calendar must be a string of at most 500000 characters")
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            raise CoremailError("Windows Simple MAPI cannot preserve text/calendar")
    calendar_method = arguments.get("calendar_method", "REQUEST")
    if not isinstance(calendar_method, str) or calendar_method.upper() not in {"REQUEST", "REPLY", "CANCEL", "PUBLISH", "COUNTER", "DECLINECOUNTER"}:
        raise CoremailError("calendar_method is not supported")
    calendar_method = calendar_method.upper()
    attachments = _prepare_attachments(settings, arguments.get("attachments"))

    domain = from_address.rsplit("@", 1)[1]
    return PreparedMessage(
        from_header=from_header,
        from_address=from_address,
        to_headers=to_headers,
        to_addresses=to_addresses,
        cc_headers=cc_headers,
        cc_addresses=cc_addresses,
        bcc_headers=bcc_headers,
        bcc_addresses=bcc_addresses,
        subject=subject,
        body_text=body_text,
        body_html=body_html,
        in_reply_to=in_reply_to,
        references=references,
        attachments=attachments,
        message_id=make_msgid(domain=domain),
        date=dt.datetime.now(dt.timezone.utc),
        reply_to_headers=reply_to_headers,
        reply_to_addresses=reply_to_addresses,
        body_calendar=body_calendar,
        calendar_method=calendar_method,
    )


@dataclass
class _PreparedEntry:
    message: PreparedMessage
    expires_at: float
    settings_fingerprint: str | None = None


class PreparedStore:
    def __init__(self, ttl_seconds: int = DEFAULT_TOKEN_TTL_SECONDS) -> None:
        self._ttl_seconds = ttl_seconds
        self._entries: dict[str, _PreparedEntry] = {}
        self._lock = threading.Lock()

    def _cleanup(self, now: float) -> None:
        expired = [token for token, entry in self._entries.items() if entry.expires_at <= now]
        for token in expired:
            del self._entries[token]

    def put(
        self,
        message: PreparedMessage,
        *,
        settings_fingerprint: str | None = None,
    ) -> tuple[str, float]:
        now = time.monotonic()
        token = secrets.token_urlsafe(32)
        expires_at = now + self._ttl_seconds
        with self._lock:
            self._cleanup(now)
            self._entries[token] = _PreparedEntry(
                message=message,
                expires_at=expires_at,
                settings_fingerprint=settings_fingerprint,
            )
        return token, expires_at

    def get_entry(self, token: str) -> _PreparedEntry:
        now = time.monotonic()
        with self._lock:
            self._cleanup(now)
            entry = self._entries.get(token)
            if entry is None:
                raise PreparedMessageError("Prepared message token is missing, expired, consumed, or belongs to another session")
            return entry

    def get(self, token: str) -> PreparedMessage:
        return self.get_entry(token).message

    def take_entry(self, token: str) -> _PreparedEntry:
        now = time.monotonic()
        with self._lock:
            self._cleanup(now)
            entry = self._entries.pop(token, None)
            if entry is None:
                raise PreparedMessageError("Prepared message token is missing, expired, consumed, or belongs to another session")
            return entry

    def take(self, token: str) -> PreparedMessage:
        return self.take_entry(token).message


def _verified_attachment_bytes(attachment: AttachmentSpec) -> bytes:
    try:
        attachment_bytes = attachment.path.read_bytes()
    except OSError as exc:
        raise PreparedMessageError(f"Prepared attachment is no longer available: {attachment.path}") from exc
    if len(attachment_bytes) != attachment.size or hashlib.sha256(attachment_bytes).hexdigest() != attachment.sha256:
        raise PreparedMessageError(
            f"Prepared attachment changed after review: {attachment.path}. Prepare the message again."
        )
    return attachment_bytes


def build_email(message: PreparedMessage) -> EmailMessage:
    mail = EmailMessage(policy=policy.SMTP)
    mail["From"] = message.from_header
    if message.to_headers:
        mail["To"] = ", ".join(message.to_headers)
    if message.cc_headers:
        mail["Cc"] = ", ".join(message.cc_headers)
    if message.bcc_headers:
        mail["Bcc"] = ", ".join(message.bcc_headers)
    mail["Subject"] = message.subject
    mail["Date"] = format_datetime(message.date)
    mail["Message-ID"] = message.message_id
    if message.in_reply_to:
        mail["In-Reply-To"] = message.in_reply_to
    if message.references:
        mail["References"] = message.references
    if message.reply_to_headers:
        mail["Reply-To"] = ", ".join(message.reply_to_headers)
    inline = [item for item in message.attachments if item.disposition == "inline"]
    if inline and not message.body_html:
        raise PreparedMessageError("Inline attachments require body_html so their Content-ID can be referenced")
    if message.body_html is None:
        mail.set_content(message.body_text)
    elif message.body_text:
        mail.set_content(message.body_text)
        mail.add_alternative(message.body_html, subtype="html")
        if inline:
            html_part = mail.get_payload()[-1]
            for attachment in inline:
                attachment_bytes = _verified_attachment_bytes(attachment)
                guessed, encoding = mimetypes.guess_type(attachment.filename)
                mime_type = attachment.content_type or (guessed if guessed and not encoding else None) or "application/octet-stream"
                maintype, subtype = mime_type.split("/", 1)
                html_part.add_related(attachment_bytes, maintype=maintype, subtype=subtype,
                                      filename=attachment.filename, cid=f"<{attachment.content_id}>", disposition="inline")
    else:
        mail.set_content(message.body_html, subtype="html")
        if inline:
            mail.make_related()
            for attachment in inline:
                attachment_bytes = _verified_attachment_bytes(attachment)
                guessed, encoding = mimetypes.guess_type(attachment.filename)
                mime_type = attachment.content_type or (guessed if guessed and not encoding else None) or "application/octet-stream"
                maintype, subtype = mime_type.split("/", 1)
                mail.add_related(attachment_bytes, maintype=maintype, subtype=subtype,
                                 filename=attachment.filename, cid=f"<{attachment.content_id}>", disposition="inline")
    for attachment in message.attachments:
        if attachment.disposition == "inline":
            continue
        attachment_bytes = _verified_attachment_bytes(attachment)
        guessed, encoding = mimetypes.guess_type(attachment.filename)
        mime_type = attachment.content_type or (guessed if guessed and not encoding else None)
        if mime_type and "/" in mime_type:
            maintype, subtype = mime_type.split("/", 1)
        else:
            maintype, subtype = "application", "octet-stream"
        mail.add_attachment(
            attachment_bytes,
            maintype=maintype,
            subtype=subtype,
            filename=attachment.filename,
        )
    if message.body_calendar is not None:
        mail.add_attachment(message.body_calendar.encode("utf-8"), maintype="text", subtype="calendar",
                            params={"method": message.calendar_method, "charset": "utf-8"}, filename=None)
    return mail


def _find_special_folder(client: imaplib.IMAP4, flag: str, fallbacks: Sequence[str]) -> str | None:
    folders = list_folders_with_client(client)
    for folder in folders:
        if any(item.lower() == flag.lower() for item in folder.get("flags", [])):
            return str(folder["name"])
    by_lower = {str(folder["name"]).lower(): str(folder["name"]) for folder in folders}
    for fallback in fallbacks:
        if fallback.lower() in by_lower:
            return by_lower[fallback.lower()]
    return None


def append_message(
    settings: Settings,
    message: PreparedMessage,
    *,
    kind: str,
) -> dict[str, Any]:
    mail = build_email(message)
    raw = mail.as_bytes(policy=policy.SMTP)
    with imap_session(settings) as client:
        if kind == "draft":
            folder = settings.drafts_folder or _find_special_folder(client, "\\Drafts", ("Drafts", "Draft", "草稿箱", "草稿"))
            flags = "\\Draft"
        elif kind == "sent":
            folder = settings.sent_folder or _find_special_folder(client, "\\Sent", ("Sent", "Sent Messages", "已发送", "已发送邮件"))
            flags = "\\Seen"
        else:
            raise CoremailError(f"Unsupported append kind: {kind}")
        if not folder:
            raise ConfigError(f"Cannot locate the IMAP {kind} folder; configure it explicitly")
        status, data = client.append(_imap_quoted(folder), flags, None, raw)
        if status != "OK":
            raise MailProtocolError(f"IMAP APPEND to {folder} failed")
        return {
            "appended": True,
            "transport": "imap_smtp",
            "kind": kind,
            "folder": folder,
            "message_id": message.message_id,
            "server_response": _safe_protocol_text(data[0]) if data else None,
        }


def _refused_recipients(value: Mapping[str, tuple[int, bytes | str]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for address, response in value.items():
        code, detail = response
        if isinstance(detail, bytes):
            detail = detail.decode("utf-8", errors="replace")
        result[address] = {"code": int(code), "message": _safe_protocol_text(detail)}
    return result


def send_message(settings: Settings, message: PreparedMessage) -> dict[str, Any]:
    mail = build_email(message)
    try:
        with smtp_session(settings) as client:
            refused = client.send_message(
                mail,
                from_addr=message.from_address,
                to_addrs=list(message.all_recipients),
            )
    except smtplib.SMTPRecipientsRefused as exc:
        raise MailProtocolError(f"SMTP rejected all recipients: {_refused_recipients(exc.recipients)}") from exc
    except (smtplib.SMTPServerDisconnected, OSError, ssl.SSLError) as exc:
        raise MailConnectionError(
            "SMTP connection failed during submission; delivery state may be uncertain. "
            "Do not retry automatically."
        ) from exc
    except smtplib.SMTPDataError as exc:
        raise MailProtocolError(f"SMTP rejected message data (code {exc.smtp_code})") from exc
    except smtplib.SMTPSenderRefused as exc:
        raise MailProtocolError(f"SMTP rejected the sender (code {exc.smtp_code})") from exc
    except smtplib.SMTPException as exc:
        raise MailProtocolError(f"SMTP submission failed: {_safe_protocol_text(exc)}") from exc

    refused_result = _refused_recipients(refused)
    accepted = [address for address in message.all_recipients if address not in refused]
    result: dict[str, Any] = {
        "smtp_submitted": bool(accepted),
        "transport": "imap_smtp",
        "message_id": message.message_id,
        "accepted_recipients": accepted,
        "refused_recipients": refused_result,
        "delivery_note": "SMTP acceptance is not final delivery confirmation.",
        "sent_copy_mode": settings.sent_copy_mode,
    }

    if accepted and settings.sent_copy_mode == "append":
        try:
            result["sent_copy"] = append_message(settings, message, kind="sent")
        except CoremailError as exc:
            result["sent_copy"] = {"appended": False, "error": str(exc)}
    else:
        result["sent_copy"] = {"appended": False, "reason": "sent_copy_mode is none"}
    return result


def _mapi_recipient_rows(message: PreparedMessage) -> list[tuple[int, str, str]]:
    rows: list[tuple[int, str, str]] = []
    for recipient_class, headers, addresses in (
        (MAPI_TO, message.to_headers, message.to_addresses),
        (MAPI_CC, message.cc_headers, message.cc_addresses),
        (MAPI_BCC, message.bcc_headers, message.bcc_addresses),
    ):
        for header, address in zip(headers, addresses):
            display_name = getaddresses([header])[0][0]
            rows.append((recipient_class, display_name, address))
    return rows


class CoremailBackend:
    def __init__(
        self,
        store: PreparedStore | None = None,
        mapi_client: SimpleMapiClient | None = None,
    ) -> None:
        self.store = store or PreparedStore()
        self._mapi_client = mapi_client
        self._settings_cache: tuple[Path, tuple[int, int, int], Settings] | None = None
        self._cursor_secret = secrets.token_bytes(32)

    def _mapi(self) -> SimpleMapiClient:
        if self._mapi_client is None:
            self._mapi_client = SimpleMapiClient()
        return self._mapi_client

    def _load_settings(self, path: Path | None = None) -> Settings:
        settings = load_settings(path)
        if path is None:
            try:
                metadata = settings.config_path.stat()
                signature = (
                    int(getattr(metadata, "st_mtime_ns", int(metadata.st_mtime * 1_000_000_000))),
                    int(metadata.st_size),
                    int(getattr(metadata, "st_ino", 0)),
                )
            except OSError:
                signature = (0, 0, 0)
            cached = self._settings_cache
            if (
                cached is not None
                and cached[0] == settings.config_path
                and cached[1] == signature
            ):
                return cached[2]
            self._settings_cache = (settings.config_path, signature, settings)
        return settings

    def _clear_settings_cache(self) -> None:
        self._settings_cache = None

    @staticmethod
    def _assert_prepared_settings(entry: _PreparedEntry, settings: Settings) -> None:
        """Keep a reviewed token tied to the settings used for its preview."""
        if (
            entry.settings_fingerprint is not None
            and entry.settings_fingerprint != _settings_fingerprint(settings)
        ):
            raise PreparedMessageError(
                "Mail configuration changed after the message was prepared; prepare the message again."
            )

    @staticmethod
    def _raise_mapi(exc: WindowsMapiError) -> None:
        message = str(exc)
        lowered = message.casefold()
        if "no existing shared login session" in lowered or "invalid or expired session" in lowered:
            message += (
                " Open the Coremail/Windows mail client, sign in again or update the expired "
                "password/token there, then retry mail_check_connection."
            )
        raise MailProtocolError(message) from exc

    def close(self) -> None:
        if self._mapi_client is not None:
            try:
                self._mapi_client.close()
            except WindowsMapiError:
                pass

    @staticmethod
    def _missing_fields_from_error(message: str) -> list[str]:
        result: list[str] = []
        patterns = (
            (r"Missing or empty configuration field: ([A-Za-z0-9_.-]+)", None),
            (r"Configuration field must be an integer: ([A-Za-z0-9_.-]+)", None),
            (r"Configuration field is outside the supported range: ([A-Za-z0-9_.-]+)", None),
            (r"Invalid server hostname in ([A-Za-z0-9_.-]+)", None),
            (r"([A-Za-z0-9_.-]+) must be a hostname or IP address", None),
            (r"([A-Za-z0-9_.-]+) must be '(?:ssl|starttls)'", None),
            (r"([A-Za-z0-9_.-]+) must be '?(?:imap_smtp|windows_simple_mapi)'?", None),
            (r"([A-Za-z0-9_.-]+) must be '?(?:none|append)'?", None),
            (r"([A-Za-z0-9_.-]+) must not be empty", None),
            (r"([A-Za-z0-9_.-]+) must be between", None),
            (r"([A-Za-z0-9_.-]+) must be a non-empty JSON array", None),
            (r"([A-Za-z0-9_.-]+) must contain at most", None),
            (r"([A-Za-z0-9_.-]+) is not permitted", None),
            (r"Unknown configuration field\(s\)(?: in [A-Za-z0-9_.-]+)?:\s*([A-Za-z0-9_.-]+)", None),
            (r"Configuration field contains a (?:newline|control character):\s*([A-Za-z0-9_.-]+)", None),
            (r"([A-Za-z0-9_.-]+) must contain only", None),
            (r"([A-Za-z0-9_.-]+) must be numeric", None),
            (r"([A-Za-z0-9_.-]+) must be a non-empty", None),
            (r"([A-Za-z0-9_.-]+) must be an integer", None),
            (r"([A-Za-z0-9_.-]+) must be '(?:none|append)'", None),
            (r"([A-Za-z0-9_.-]+) and [A-Za-z0-9_.-]+ configuration objects are required", "imap,smtp"),
            (r"imap and smtp settings are not permitted", "imap,smtp"),
            (r"drafts_folder and sent_folder are not permitted", "drafts_folder,sent_folder"),
            (r"Configured CA file does not exist", "ca_file"),
            (r"attachment_roots must be a JSON array", "attachment_roots"),
            (r"must be 'coremail'", "provider"),
            (r"schema_version must be 1", "schema_version"),
            (r"Both imap and smtp configuration objects are required", "imap,smtp"),
            (r"Mail configuration root must be a JSON object", "root"),
        )
        for pattern, fixed in patterns:
            match = re.search(pattern, message)
            if match:
                value = fixed or match.group(1)
                result.extend(value.split(","))
        lowered = message.lower()
        if not result and "not configured" in lowered:
            result.extend(["schema_version", "provider", "username"])
        return list(dict.fromkeys(item for item in result if item))

    @staticmethod
    def _config_missing_fields(path: Path) -> tuple[list[str], str | None, dict[str, Any] | None]:
        """Collect actionable field names without ever returning field values."""
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            return ["root"], f"Cannot parse mail configuration: {path}: {exc}", None
        except (OSError, UnicodeError) as exc:
            return ["settings.json"], f"Cannot read mail configuration: {path}: {exc}", None
        if not isinstance(raw, dict):
            return ["root"], "Mail configuration root must be a JSON object", None
        missing: list[str] = []
        for field in ("schema_version", "provider", "username"):
            value = raw.get(field)
            if field not in raw or value is None or (isinstance(value, str) and not value.strip()):
                missing.append(field)
        if "transport" in raw and (
            raw.get("transport") is None
            or (isinstance(raw.get("transport"), str) and not raw["transport"].strip())
        ):
            missing.append("transport")
        transport = str(raw.get("transport", "imap_smtp")).strip().lower()
        if transport == "imap_smtp":
            for field in ("imap", "smtp"):
                if not isinstance(raw.get(field), dict):
                    missing.append(field)
                else:
                    endpoint = raw[field]
                    for child in ("host", "port", "security"):
                        value = endpoint.get(child)
                        if child not in endpoint or value is None or (
                            isinstance(value, str) and not value.strip()
                        ):
                            missing.append(f"{field}.{child}")
        return list(dict.fromkeys(missing)), None, raw

    @staticmethod
    def _config_root() -> Path:
        path = default_config_path()
        return path.parent if os.name == "nt" else path.parent.resolve()

    @classmethod
    def _validate_config_path(cls, path: Path) -> Path:
        """Accept only the one documented user-owned settings path.

        The MCP contract deliberately has one configuration location.  A
        caller-supplied path is therefore useful only when it is the same path
        with a different Windows case spelling; allowing arbitrary descendants
        would make it possible to create a second, silently ignored account
        configuration.
        """
        try:
            # Keep a lexical copy for link checks.  Calling ``resolve`` first
            # would erase a user-created symlink/junction from the path we need
            # to protect.
            lexical = Path(os.path.abspath(path.expanduser()))
            resolved = lexical.resolve()
        except (OSError, RuntimeError, ValueError) as exc:
            raise ConfigError(f"config_path is not a valid local path: {path}") from exc
        expected = default_config_path()
        if os.name == "nt":
            normalize_windows = lambda value: str(value).replace("/", "\\").rstrip("\\").casefold()
            same_path = normalize_windows(lexical) == normalize_windows(expected)
        else:
            same_path = resolved == expected
        if not same_path:
            raise ConfigError(
                f"config_path must be the managed mail settings path: {expected}"
            )
        # Windows junctions/reparse points can redirect a path outside the
        # managed directory.  Inspect the lexical chain without following it;
        # POSIX development hosts commonly expose /var through a compatibility
        # symlink, so this stricter chain check is intentionally Windows-only.
        if os.name == "nt":
            _assert_default_config_path_safe(lexical, os.environ)
            return lexical
        return resolved

    def config_status(self) -> dict[str, Any]:
        path = default_config_path()
        try:
            interface = detect_coremail_mapi_registration()
        except Exception:
            # Status is an offline diagnostic boundary.  A broken registry or
            # provider probe must not hide the configuration path and field
            # hints that the caller needs to repair the account.
            interface = {
                "available": False,
                "reason": "provider interface probe unavailable",
            }
        status: dict[str, Any] = {
            "configured": False,
            "config_path": str(path),
            "schema_version": CONFIG_SCHEMA_VERSION,
            "provider": CONFIG_PROVIDER,
            "missing_fields": [],
            "next_command": "Run CONFIGURE.cmd to create or update the mail configuration.",
            "next_step": "Run CONFIGURE.cmd to create or update the mail configuration.",
            "invalid_fields": [],
            "client_interface": interface,
            "mail_client_interface_selected": False,
            "mail_client_interface_used": False,
            "mail_ui_automation_used": False,
        }
        try:
            _assert_default_config_path_safe(path, os.environ)
        except ConfigError as exc:
            status["error"] = str(exc)
            status["missing_fields"] = ["settings.json"]
            status["next_command"] = "Run CONFIGURE.cmd to recreate the managed settings file."
            status["next_step"] = status["next_command"]
            return status
        if not path.is_file():
            status["missing_fields"] = ["schema_version", "provider", "username"]
            return status
        missing, read_error, raw = self._config_missing_fields(path)
        if read_error:
            status["missing_fields"] = missing
            status["invalid_fields"] = [field for field in missing if field not in {"settings.json"}]
            status["error"] = read_error
            status["next_command"] = "Run CONFIGURE.cmd, then reload the MCP server."
            status["next_step"] = status["next_command"]
            return status
        if raw is not None:
            if isinstance(raw.get("schema_version"), int) and not isinstance(raw.get("schema_version"), bool):
                status["schema_version"] = raw["schema_version"]
            if isinstance(raw.get("provider"), str) and raw["provider"].strip():
                status["provider"] = raw["provider"].strip().lower()
        if missing:
            status["missing_fields"] = missing
        try:
            # Use the default-path branch so the same lexical reparse-point
            # check is applied immediately before reading the file.
            settings = self._load_settings()
        except ConfigError as exc:
            parsed_missing = self._missing_fields_from_error(str(exc))
            status["missing_fields"] = list(dict.fromkeys(status["missing_fields"] + parsed_missing))
            status["invalid_fields"] = parsed_missing
            status["next_command"] = "Run CONFIGURE.cmd, then reload the MCP server."
            status["next_step"] = status["next_command"]
            status["error"] = str(exc)
            return status
        return {
            "configured": True,
            "config_path": str(settings.config_path),
            "schema_version": settings.schema_version,
            "provider": settings.provider,
            "transport": settings.transport,
            "credential_available": (
                credential_available(settings) if settings.transport == "imap_smtp" else None
            ),
            "settings": settings.public_summary(),
            "capabilities": settings.body_capabilities(),
            "client_interface": interface,
            "mail_client_interface_selected": settings.transport == WINDOWS_MAPI_TRANSPORT,
            "mail_client_interface_used": False,
            "mail_ui_automation_used": False,
            "missing_fields": [],
            "next_command": "Run mail_config_reload after changing settings.",
            "next_step": "Run mail_config_reload after changing settings.",
            "invalid_fields": [],
        }

    def configure(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        allowed_keys = {
            "config_path", "schema_version", "provider", "transport", "username",
            "credential_target", "imap", "smtp", "allowed_from", "drafts_folder",
            "sent_folder", "sent_copy_mode", "ca_file", "attachment_roots",
            "max_message_bytes", "max_body_chars", "max_attachment_bytes",
            "max_recipients", "timeout_seconds",
            "auth_method", "download_directory",
        }
        unknown = sorted(str(key) for key in arguments if key not in allowed_keys)
        if unknown:
            raise ConfigError(f"Unknown configuration field(s): {', '.join(unknown)}")
        path_value = arguments.get("config_path")
        if path_value is not None and not isinstance(path_value, str):
            raise ConfigError("config_path must be a string path")
        if isinstance(path_value, str) and not path_value.strip():
            raise ConfigError("config_path must not be empty")
        config_path = self._validate_config_path(
            Path(path_value) if isinstance(path_value, str) else default_config_path()
        )
        if os.name == "nt":
            _assert_default_config_path_safe(config_path, os.environ)
        if config_path.is_dir():
            raise ConfigError(f"config_path must point to a JSON file: {config_path}")
        config_path.parent.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            _assert_default_config_path_safe(config_path, os.environ)
        current: dict[str, Any] = {}
        if config_path.is_file():
            try:
                current = json.loads(config_path.read_text(encoding="utf-8"))
                if not isinstance(current, dict):
                    current = {}
            except (OSError, UnicodeError, json.JSONDecodeError):
                current = {}
        current.setdefault("schema_version", CONFIG_SCHEMA_VERSION)
        current.setdefault("provider", CONFIG_PROVIDER)
        for key in (
            "schema_version",
            "provider",
            "transport",
            "username",
            "credential_target",
            "imap",
            "smtp",
            "allowed_from",
            "drafts_folder",
            "sent_folder",
            "sent_copy_mode",
            "ca_file",
            "attachment_roots",
            "max_message_bytes",
            "max_body_chars",
            "max_attachment_bytes",
            "max_recipients",
            "timeout_seconds",
            "auth_method",
            "download_directory",
        ):
            if key in arguments and arguments[key] is not None:
                current[key] = arguments[key]

        # ``mail_configure`` is a partial update, but transport changes also
        # change which fields are legal.  A previous IMAP/SMTP configuration
        # must not make a valid switch to Simple MAPI impossible merely because
        # its old endpoint and credential metadata were merged into the staged
        # document.  Drop only stale fields that were omitted by the caller;
        # explicitly supplied incompatible values remain in the staged object
        # and are rejected by the common parser, preserving typo detection.
        requested_transport = current.get("transport", "imap_smtp")
        if isinstance(requested_transport, str) and requested_transport.strip().lower() == WINDOWS_MAPI_TRANSPORT:
            for key in (
                "credential_target",
                "imap",
                "smtp",
                "ca_file",
                "drafts_folder",
                "sent_folder",
                "auth_method",
                "download_directory",
            ):
                if key not in arguments or arguments[key] is None:
                    current.pop(key, None)
            if "sent_copy_mode" not in arguments:
                current["sent_copy_mode"] = "none"
            if "allowed_from" not in arguments:
                username = current.get("username")
                if isinstance(username, str) and username.strip():
                    current["allowed_from"] = [username.strip()]
        rendered = json.dumps(current, indent=2, ensure_ascii=False, sort_keys=True) + "\n"
        staged_path = config_path.with_name(f".{config_path.name}.staged-{secrets.token_hex(8)}")
        staged_path.write_text(rendered, encoding="utf-8")
        try:
            self._load_settings(staged_path)
        finally:
            staged_path.unlink(missing_ok=True)
        replacement = config_path.with_name(f".{config_path.name}.tmp-{secrets.token_hex(8)}")
        try:
            replacement.write_text(rendered, encoding="utf-8")
            if os.name == "nt":
                _assert_default_config_path_safe(config_path, os.environ)
            os.replace(replacement, config_path)
        finally:
            # Keep a failed atomic update from leaving a second settings file
            # containing account metadata in the managed directory.
            replacement.unlink(missing_ok=True)
        try:
            config_path.chmod(0o600)
        except OSError:
            pass
        self._clear_settings_cache()
        return self.config_status()

    def reload_config(self) -> dict[str, Any]:
        self._clear_settings_cache()
        return self.config_status()

    def mail_connection_status(self) -> dict[str, Any]:
        # Reuse the structured, secret-free status path so malformed or unsafe
        # configuration produces actionable field hints instead of an opaque
        # tool error.  This method adds transport-specific labels only after a
        # valid settings object is available.
        status = self.config_status()
        if not status.get("configured"):
            status.setdefault(
                "next_step",
                status.get("next_command", "Run CONFIGURE.cmd, then reload the MCP server."),
            )
            return status
        settings = self._load_settings()
        interface = status.get("client_interface")
        credential_is_available = (
            credential_available(settings) if settings.transport == "imap_smtp" else None
        )
        next_step = "Run mail_check_connection to verify the active mail transport."
        if settings.transport == "imap_smtp" and not credential_is_available:
            next_step = (
                "The configured mailbox credential is unavailable or empty. "
                + _credential_update_instruction(settings)
                + " Never send the password or token to an MCP tool."
            )
        return {
            "configured": True,
            "config_path": str(settings.config_path),
            "schema_version": settings.schema_version,
            "provider": settings.provider,
            "missing_fields": [],
            "active_transport": settings.transport,
            "capabilities": settings.body_capabilities(),
            "credential_available": credential_is_available,
            "settings": settings.public_summary(),
            "client_interface": interface,
            "mail_client_interface_selected": settings.transport == WINDOWS_MAPI_TRANSPORT,
            "mail_client_interface_used": False,
            "mail_ui_automation_used": False,
            "next_step": next_step,
        }

    def check_connection(self) -> dict[str, Any]:
        settings = self._load_settings()
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            try:
                result = self._mapi().status()
            except WindowsMapiError as exc:
                self._raise_mapi(exc)
            return {
                **result,
                "username": settings.username,
                "mail_client_interface_used": True,
                "mail_ui_automation_used": False,
            }

        with imap_session(settings) as imap_client:
            imap_capabilities = sorted(
                item.decode("ascii", errors="replace") if isinstance(item, bytes) else str(item)
                for item in getattr(imap_client, "capabilities", ())
            )
        with smtp_session(settings) as smtp_client:
            smtp_client.ehlo_or_helo_if_needed()
            smtp_features = sorted(smtp_client.esmtp_features.keys())
        return {
            "transport": "imap_smtp",
            "imap": {"connected": True, "capabilities": imap_capabilities},
            "smtp": {"connected": True, "features": smtp_features},
            "capabilities": settings.body_capabilities(),
            "username": settings.username,
            "tls_verification": True,
            "mail_client_interface_used": False,
            "mail_ui_automation_used": False,
        }

    # Internal callers that used the pre-generalization method name can keep
    # using it; the MCP surface exposes only the mail_* name.
    def connection_status(self) -> dict[str, Any]:
        return self.mail_connection_status()

    def list_folders(self) -> dict[str, Any]:
        settings = self._load_settings()
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            try:
                return self._mapi().list_folders()
            except WindowsMapiError as exc:
                self._raise_mapi(exc)
        with imap_session(settings) as client:
            folders = list_folders_with_client(client)
        return {"folders": folders, "count": len(folders), "transport": "imap_smtp"}

    def search(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        folder = arguments.get("folder", "INBOX")
        if not isinstance(folder, str):
            raise CoremailError("folder must be a string")
        query = arguments.get("query", {})
        if not isinstance(query, dict):
            raise CoremailError("query must be an object")
        limit = _bounded_tool_int(arguments.get("limit", _MISSING), "limit", 20, 1, 100)
        cursor_payload: dict[str, Any] | None = None
        cursor = arguments.get("cursor")
        if cursor is not None:
            if not isinstance(cursor, str) or len(cursor) > 4096:
                raise CoremailError("cursor is invalid")
            try:
                encoded, signature = cursor.rsplit(".", 1)
                expected = hmac.new(self._cursor_secret, encoded.encode("ascii"), hashlib.sha256).hexdigest()
                if not hmac.compare_digest(expected, signature):
                    raise ValueError
                cursor_payload = json.loads(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)).decode("utf-8"))
                if not isinstance(cursor_payload, dict) or float(cursor_payload.get("expires_at", 0)) < time.time():
                    raise ValueError
            except (ValueError, TypeError, KeyError, json.JSONDecodeError, UnicodeError):
                raise CoremailError("cursor is invalid or expired")
            if cursor_payload.get("folder") != folder or cursor_payload.get("query") != query:
                raise CoremailError("cursor does not belong to this folder and query")
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            if cursor is not None:
                raise CoremailError("Pagination cursors are available only in imap_smtp mode; Simple MAPI search is session-bounded")
            try:
                return self._mapi().search(folder=folder, query=query, limit=limit)
            except WindowsMapiError as exc:
                self._raise_mapi(exc)
        with imap_session(settings) as client:
            result = search_messages_with_client(client, folder=folder, query=query, limit=limit,
                                                 uid_after=int(cursor_payload["last_uid"]) if cursor_payload and cursor_payload.get("last_uid") is not None else None,
                                                 snapshot_uid=int(cursor_payload["snapshot_uid"]) if cursor_payload and cursor_payload.get("snapshot_uid") is not None else None,
                                                 expected_uidvalidity=str(cursor_payload["uidvalidity"]) if cursor_payload and cursor_payload.get("uidvalidity") is not None else None)
        if result.get("has_more") and result.get("last_uid") is not None:
            payload = {"folder": folder, "query": query, "snapshot_uid": result.get("snapshot_uid"),
                       "last_uid": result.get("last_uid"), "uidvalidity": result.get("uidvalidity"),
                       "expires_at": time.time() + 15 * 60}
            encoded = base64.urlsafe_b64encode(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).decode("ascii").rstrip("=")
            result["next_cursor"] = encoded + "." + hmac.new(self._cursor_secret, encoded.encode("ascii"), hashlib.sha256).hexdigest()
        else:
            result["next_cursor"] = None
        return {**result, "transport": "imap_smtp"}

    def get_message(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        folder = arguments.get("folder", "INBOX")
        if not isinstance(folder, str):
            raise CoremailError("folder must be a string")
        uid = str(arguments.get("uid", ""))
        uidvalidity = arguments.get("uidvalidity")
        requested_chars = _bounded_tool_int(
            arguments.get("max_body_chars", _MISSING),
            "max_body_chars",
            settings.max_body_chars,
            1,
            settings.max_body_chars,
        )
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            try:
                return self._mapi().get_message(
                    folder=folder,
                    uid=uid,
                    expected_uidvalidity=str(uidvalidity) if uidvalidity is not None else None,
                    max_body_chars=requested_chars,
                )
            except WindowsMapiError as exc:
                self._raise_mapi(exc)
        with imap_session(settings) as client:
            result = get_message_with_client(
                client,
                folder=folder,
                uid=uid,
                expected_uidvalidity=str(uidvalidity) if uidvalidity is not None else None,
                max_message_bytes=settings.max_message_bytes,
                max_body_chars=requested_chars,
            )
        return {**result, "transport": "imap_smtp"}

    def set_seen(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        folder = arguments.get("folder", "INBOX")
        if not isinstance(folder, str):
            raise CoremailError("folder must be a string")
        uid = str(arguments.get("uid", ""))
        uidvalidity = arguments.get("uidvalidity")
        seen = arguments.get("seen")
        if not isinstance(seen, bool):
            raise CoremailError("seen must be true or false")
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            try:
                return self._mapi().set_seen(
                    folder=folder,
                    uid=uid,
                    expected_uidvalidity=str(uidvalidity) if uidvalidity is not None else None,
                    seen=seen,
                )
            except WindowsMapiError as exc:
                self._raise_mapi(exc)
        with imap_session(settings) as client:
            result = set_seen_with_client(
                client,
                folder=folder,
                uid=uid,
                expected_uidvalidity=str(uidvalidity) if uidvalidity is not None else None,
                seen=seen,
            )
        return {**result, "transport": "imap_smtp"}

    def set_flags(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        folder = arguments.get("folder", "INBOX")
        uid = str(arguments.get("uid", ""))
        uidvalidity = arguments.get("uidvalidity")
        if not isinstance(folder, str):
            raise CoremailError("folder must be a string")
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            raise CoremailError("Windows Simple MAPI does not expose IMAP flags or keywords")
        with imap_session(settings) as client:
            result = set_flags_with_client(client, folder=folder, uid=uid,
                                           expected_uidvalidity=str(uidvalidity) if uidvalidity is not None else None,
                                           add=arguments.get("add"), remove=arguments.get("remove"))
        return {**result, "transport": "imap_smtp"}

    def copy_move(self, arguments: Mapping[str, Any], *, move: bool) -> dict[str, Any]:
        settings = self._load_settings()
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            raise CoremailError("Windows Simple MAPI does not expose mailbox copy or move")
        folder = arguments.get("folder", "INBOX")
        destination = arguments.get("destination")
        if not isinstance(folder, str) or not isinstance(destination, str):
            raise CoremailError("folder and destination must be strings")
        with imap_session(settings) as client:
            result = copy_or_move_with_client(client, folder=folder, uid=str(arguments.get("uid", "")),
                                              destination=destination,
                                              expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None,
                                              move=move)
        return {**result, "transport": "imap_smtp"}

    def delete_message(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            try:
                return self._mapi().delete_message(folder=str(arguments.get("folder", "INBOX")), uid=str(arguments.get("uid", "")),
                                                   expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None,
                                                   permanent=bool(arguments.get("permanent", False)))
            except WindowsMapiError as exc:
                self._raise_mapi(exc)
        folder = arguments.get("folder", "INBOX")
        if not isinstance(folder, str):
            raise CoremailError("folder must be a string")
        with imap_session(settings) as client:
            result = delete_with_client(client, folder=folder, uid=str(arguments.get("uid", "")),
                                        expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None,
                                        permanent=bool(arguments.get("permanent", False)))
        return {**result, "transport": "imap_smtp"}

    def manage_folder(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            raise CoremailError("Windows Simple MAPI exposes only the INBOX folder")
        action = arguments.get("action")
        folder = arguments.get("folder")
        if not isinstance(action, str) or not isinstance(folder, str):
            raise CoremailError("action and folder are required strings")
        with imap_session(settings) as client:
            result = manage_folder_with_client(client, action=action, folder=folder,
                                               new_name=arguments.get("new_name"),
                                               allow_nonempty=bool(arguments.get("allow_nonempty", False)))
        return {**result, "transport": "imap_smtp"}

    def get_raw_message(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            raise CoremailError("Windows Simple MAPI does not expose the original RFC 822 source")
        folder = arguments.get("folder", "INBOX")
        offset = _bounded_tool_int(arguments.get("offset", _MISSING), "offset", 0, 0, 2**31 - 1)
        length = _bounded_tool_int(arguments.get("length", _MISSING), "length", 256 * 1024, 1, 256 * 1024)
        with imap_session(settings) as client:
            result = fetch_raw_chunk_with_client(client, folder=folder, uid=str(arguments.get("uid", "")),
                                                 expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None,
                                                 offset=offset, length=length)
        return {**result, "transport": "imap_smtp"}

    def download_attachment(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        if "save" in arguments and not isinstance(arguments.get("save"), bool):
            raise CoremailError("save must be true or false")
        folder = arguments.get("folder", "INBOX")
        part_id = arguments.get("part_id")
        if not isinstance(folder, str) or not isinstance(part_id, str):
            raise CoremailError("folder and part_id are required strings")
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            if folder.casefold() != "inbox" or not part_id.isdigit() or int(part_id) < 1:
                raise CoremailError("Simple MAPI attachments use one-based numeric part_id values in INBOX")
            try:
                result = self._mapi().download_attachment(
                    folder=folder, uid=str(arguments.get("uid", "")),
                    expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None,
                    index=int(part_id) - 1,
                )
            except WindowsMapiError as exc:
                self._raise_mapi(exc)
            provider_filename = result.get("filename") or f"attachment-{part_id}.bin"
            filename = arguments.get("filename") or Path(str(provider_filename)).name
            if not isinstance(filename, str) or not filename or Path(filename).name != filename or any(char in filename for char in "/\\") or filename in {".", ".."}:
                raise CoremailError("filename must be a safe file name")
            if arguments.get("save", False):
                directory = settings.download_directory
                if directory is None:
                    raise CoremailError("Saving downloads requires download_directory in mail configuration")
                directory.mkdir(parents=True, exist_ok=True)
                destination = directory / filename
                if destination.exists():
                    raise CoremailError(f"Refusing to overwrite existing download: {destination}")
                data = base64.b64decode(result["data_base64"])
                temporary = destination.with_name(f".{destination.name}.tmp-{secrets.token_hex(8)}")
                try:
                    with temporary.open("xb") as handle:
                        handle.write(data)
                    os.replace(temporary, destination)
                finally:
                    temporary.unlink(missing_ok=True)
                result["saved_path"] = str(destination)
            return {**result, "filename": filename}
        with imap_session(settings) as client:
            result = download_attachment_with_client(client, folder=folder, uid=str(arguments.get("uid", "")),
                                                     part_id=part_id,
                                                     expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None,
                                                     max_message_bytes=settings.max_message_bytes)
        filename = arguments.get("filename") or result.get("filename") or f"attachment-{part_id.replace('.', '-')}.bin"
        if not isinstance(filename, str) or Path(filename).name != filename or any(char in filename for char in "/\\") or filename in {".", ".."}:
            raise CoremailError("filename must be a safe file name")
        if arguments.get("save", False):
            directory = settings.download_directory
            if directory is None:
                raise CoremailError("Saving downloads requires download_directory in mail configuration")
            directory.mkdir(parents=True, exist_ok=True)
            destination = directory / filename
            if destination.exists():
                raise CoremailError(f"Refusing to overwrite existing download: {destination}")
            data = base64.b64decode(result["data_base64"])
            temporary = destination.with_name(f".{destination.name}.tmp-{secrets.token_hex(8)}")
            try:
                with temporary.open("xb") as handle:
                    handle.write(data)
                os.replace(temporary, destination)
            finally:
                temporary.unlink(missing_ok=True)
            result["saved_path"] = str(destination)
        return {**result, "filename": filename, "transport": "imap_smtp"}

    def update_draft(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        token = str(arguments.get("prepared_token", ""))
        settings = self._load_settings()
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            raise CoremailError("Draft replacement is unavailable through Windows Simple MAPI")
        entry = self.store.get_entry(token)
        self._assert_prepared_settings(entry, settings)
        folder = arguments.get("folder") or settings.drafts_folder
        if folder is not None and not isinstance(folder, str):
            raise CoremailError("folder must be a string")
        message = self.store.take_entry(token).message
        with imap_session(settings) as client:
            if not folder:
                folder = _find_special_folder(client, "\\Drafts", ("Drafts", "Draft", "草稿箱", "草稿"))
            if not folder:
                raise ConfigError("Cannot locate the IMAP Drafts folder; configure it explicitly")
            result = update_draft_with_client(client, settings=settings, message=message, folder=folder,
                                              uid=str(arguments.get("uid", "")),
                                              expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None,
                                              expected_sha256=arguments.get("expected_sha256"))
        return {**result, "transport": "imap_smtp"}

    def watch_folder(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            raise CoremailError("Windows Simple MAPI does not expose IMAP IDLE or mailbox change events")
        folder = arguments.get("folder", "INBOX")
        timeout = _bounded_tool_int(arguments.get("timeout_seconds", _MISSING), "timeout_seconds", 15, 1, 30)
        with imap_session(settings) as client:
            selected = select_folder(client, folder, readonly=True, expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None)
            idle_supported = any((item.decode(errors="ignore") if isinstance(item, bytes) else str(item)).upper() == "IDLE" for item in getattr(client, "capabilities", ()))
            used_idle = False
            changed = False
            if idle_supported:
                idle_result = _imap_idle_wait(client, timeout)
                if idle_result is not None:
                    changed = idle_result
                    used_idle = True
            if not used_idle:
                deadline = time.monotonic() + timeout
                while time.monotonic() < deadline:
                    try:
                        client.noop()
                    except (imaplib.IMAP4.error, OSError) as exc:
                        raise MailConnectionError("IMAP watch connection failed") from exc
                    time.sleep(min(1.0, max(0.0, deadline - time.monotonic())))
            refreshed = select_folder(client, folder, readonly=True,
                                      expected_uidvalidity=str(arguments["uidvalidity"]) if arguments.get("uidvalidity") is not None else None)
        return {"folder": folder, "uidvalidity": refreshed.get("uidvalidity"),
                "message_count_before": selected.get("message_count"), "message_count_after": refreshed.get("message_count"),
                "changed": changed or selected.get("message_count") != refreshed.get("message_count"),
                "waited_seconds": timeout, "mode": "idle" if used_idle else "poll",
                "idle_available": idle_supported, "transport": "imap_smtp"}

    def prepare(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        settings = self._load_settings()
        message = prepare_message(settings, arguments)
        token, _ = self.store.put(
            message,
            settings_fingerprint=_settings_fingerprint(settings),
        )
        return {
            "prepared_token": token,
            "expires_in_seconds": DEFAULT_TOKEN_TTL_SECONDS,
            "summary": message.summary(settings),
            "network_write_performed": False,
        }

    def save_draft(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        token = str(arguments.get("prepared_token", ""))
        settings = self._load_settings()
        entry = self.store.get_entry(token)
        self._assert_prepared_settings(entry, settings)
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            self._assert_mapi_message_supported(entry.message)
            if not hasattr(self._mapi(), "save_draft"):
                raise CoremailError("Saving drafts is not supported by the registered Windows Simple MAPI provider")
            message = entry.message
            sender_name = getaddresses([message.from_header])[0][0]
            verified = [(item, _verified_attachment_bytes(item)) for item in message.attachments]
            with tempfile.TemporaryDirectory(prefix="coremail-mapi-draft-") as temporary:
                snapshots: list[tuple[str, str]] = []
                for index, (attachment, content) in enumerate(verified, start=1):
                    snapshot = Path(temporary) / f"attachment-{index:03d}.bin"
                    with snapshot.open("xb") as handle:
                        handle.write(content)
                    snapshots.append((str(snapshot), attachment.filename))
                try:
                    result = self._mapi().save_draft(sender_address=message.from_address,
                                                     recipients=_mapi_recipient_rows(message), subject=message.subject,
                                                     body=message.body_text, attachments=snapshots,
                                                     message_id=message.message_id)
                except WindowsMapiError as exc:
                    raise CoremailError(f"Saving drafts failed: {exc}") from exc
            self.store.take_entry(token)
            return result
        message = self.store.take_entry(token).message
        return append_message(settings, message, kind="draft")

    def _send_mapi(self, settings: Settings, message: PreparedMessage) -> dict[str, Any]:
        self._assert_mapi_message_supported(message)
        sender_name = getaddresses([message.from_header])[0][0]
        verified = [(item, _verified_attachment_bytes(item)) for item in message.attachments]
        # Simple MAPI accepts attachment paths rather than bytes. Pass random-name,
        # verified snapshots so a change to the original file after review cannot
        # race the provider's copy. Microsoft documents that attachments are copied
        # before MAPISendMailW returns, so cleanup after the call is safe.
        with tempfile.TemporaryDirectory(prefix="coremail-mapi-send-") as temporary:
            snapshots: list[tuple[str, str]] = []
            for index, (attachment, content) in enumerate(verified, start=1):
                snapshot = Path(temporary) / f"attachment-{index:03d}.bin"
                try:
                    with snapshot.open("xb") as handle:
                        handle.write(content)
                except OSError as exc:
                    raise PreparedMessageError("Cannot create a verified temporary MAPI attachment") from exc
                snapshots.append((str(snapshot), attachment.filename))
            try:
                return self._mapi().send(
                    sender_name=sender_name,
                    sender_address=message.from_address,
                    recipients=_mapi_recipient_rows(message),
                    subject=message.subject,
                    body=message.body_text,
                    attachments=snapshots,
                    message_id=message.message_id,
                )
            except WindowsMapiError as exc:
                self._raise_mapi(exc)

    @staticmethod
    def _assert_mapi_message_supported(message: PreparedMessage) -> None:
        if message.body_html is not None:
            raise PreparedMessageError(
                "Windows Simple MAPI supports text/plain only; configure imap_smtp to send HTML"
            )
        if message.in_reply_to or message.references:
            raise PreparedMessageError(
                "Windows Simple MAPI cannot preserve In-Reply-To or References; use imap_smtp for this reply"
            )
        if (message.reply_to_headers or message.body_calendar is not None
                or any(item.disposition == "inline" or item.content_type is not None for item in message.attachments)):
            raise PreparedMessageError(
                "Windows Simple MAPI cannot preserve Reply-To, calendar, or custom MIME attachment parts; use imap_smtp"
            )

    def send_prepared(self, arguments: Mapping[str, Any]) -> dict[str, Any]:
        token = str(arguments.get("prepared_token", ""))
        confirmation = arguments.get("confirmation")
        if confirmation != "确认发送":
            raise PreparedMessageError("Exact confirmation phrase required: 确认发送")
        settings = self._load_settings()
        entry = self.store.get_entry(token)
        self._assert_prepared_settings(entry, settings)
        preview = entry.message
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            self._assert_mapi_message_supported(preview)
        message = self.store.take_entry(token).message
        if settings.transport == WINDOWS_MAPI_TRANSPORT:
            return self._send_mapi(settings, message)
        return send_message(settings, message)
